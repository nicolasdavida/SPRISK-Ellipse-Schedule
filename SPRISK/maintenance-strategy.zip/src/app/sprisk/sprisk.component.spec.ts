import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SpriskComponent } from './sprisk.component';

describe('SpriskComponent', () => {
  let component: SpriskComponent;
  let fixture: ComponentFixture<SpriskComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SpriskComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SpriskComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
