import { DatatableComponent } from '@swimlane/ngx-datatable';
import { Component, OnInit, AfterViewInit, ViewChild } from '@angular/core';
import { DataService } from '../shared/services/data.service';
import { toBase64String } from '@angular/compiler/src/output/source_map';

import * as XLSX from 'xlsx';
import { saveAs } from 'file-saver';

declare const $: any;
declare const UIkit: any;
declare const Highcharts: any;
declare const numeral: any;
declare const moment: any;

@Component({
  selector: 'app-sprisk',
  templateUrl: './sprisk.component.html',
  styleUrls: ['./sprisk.component.scss']
})

export class SpriskComponent implements OnInit, AfterViewInit {
  objectKeys = Object.keys;
  currentNode = null;
  moduleInfo: any = { 'title': 'SPRISK', 'key': 'sprisk' };

  math = Math;
  numeral = numeral;
  isNaN = isNaN;

  treeContainerId = '#cgs-dlf';
  markersList = null;
  currentNodes = [];
  currentParts = [];
  parts = [];

  isCompanyTreeStructureLoaded = false;
  isPartsLoaded = false;


  currentStep = 'report-selection';
  report = {
    name: null,
    type: null,
    date: null,
    chart: {
      svg: null
    },
    config: {
      source: 'ws', // ws {fechas desde-hasta}, db {periodo en meses}
      date_from: moment().format('YYYY-MM-DD'),
      date_to: moment().format('YYYY-MM-DD'),
      horizon: 30,
      mode: {
        selected: 'linear',
        value: null,
        modes: [
          { id: 'linear', name: 'Lineal' },
          { id: 'log', name: 'Logarítmico' },
          { id: 'constant', name: 'Constante' },
          { id: 'pow', name: 'Potencia' },
          { id: 'exponential', name: 'Exponencial' }
        ]
      },
      period: {
        selected: 6,
        periods: [
          { value: 6, name: '6 meses' },
          { value: 12, name: '12 meses' },
          { value: 24, name: '24 meses' }
        ]
      },
      risk_reduction: {
        enabled: false,
        value: null
      }
    },
    results: {},
    global_sr: 0,
    global_fr: 0,
    chart_sectors: null,
    visible_columns: null
  };
  selectionMode = 'assets';
  isoLinesCount = 5;

  // Jack Knife
  chart: any = {
    container_id: 'cgs-report-jackknife-chart',
    unit: '%',
    name: 'Jack-Knife',
    data: [],
    axisType: 'logarithmic'
  };
  hcChart: any = null;
  chartLabels = [];
  errorLabel = null;
  chartSectors = {
    top_left: 'Riesgo Stock',
    top_right: 'Riesgo Operacional y Stock',
    bot_left: 'Bajo Control',
    bot_right: 'Riesgo Operacional'
  };
  chartSectorsVisibility = {
    top_left: true,
    top_right: true,
    bot_left: true,
    bot_right: true
  };
  adjustJackKnifeAxis = false;

  calculationStatus = 0;

  /* Variables de las tablas */
  // partsTable es la tabla de repuestos en en reporte
  @ViewChild(DatatableComponent) partsTable: DatatableComponent;
  // mainPartsTable es la tabla de repuestos seleccionables en el panel izquierdo
  @ViewChild(DatatableComponent) mainPartsTable: DatatableComponent;
  selected = [];
  selectedMain = [];
  temp = [];
  tempMain = [];
  searchFields = ['name', 'code', 'erp_code', 'description', 'observations'];
  searchFieldsMain = ['name', 'code', 'part_number'];

  // Definicion de visibilidad de columnas en reporte
  columnsVisibility = {
    name: { id: 'name', visible: true, name: 'Nombre' },
    code: { id: 'code', visible: true, name: 'Código' },
    stock_quantity: { id: 'stock_quantity', visible: true, name: 'Stock' },
    stock_quantity_suggested: { id: 'stock_quantity_suggested', visible: false, name: 'Stock Sugerido' },
    cost: { id: 'cost', visible: true, name: 'Costo (USD)' },
    cost_expected: { id: 'cost_expected', visible: false, name: 'Costo Esperado (USD)' },
    stock_risk: { id: 'stock_risk', visible: true, name: 'RS' },
    failure_risk: { id: 'failure_risk', visible: true, name: 'RF' },
    criticality: { id: 'criticality', visible: true, name: 'Criticidad' },
    sector_global: { id: 'sector_global', visible: true, name: 'Sector Global' },
    sector_relative: { id: 'sector_relative', visible: true, name: 'Sector Relativo' }
  };

  constructor(private dataService: DataService) { }

  ngOnInit() {
    const that = this;
    (function (H) {
      H.wrap(H.Chart.prototype, 'initReflow', function (proceed) {
        const chart = this;
        proceed.call(this);
        H.addEvent(window, 'beforeprint', function () {
          chart._screenMediaWidth = chart.chartWidth;
          chart.setSize(chart.options.chart.printWidth, chart.chartHeight, false);
          // Se dibujan las etiquetas JK
          that.drawJackKnifeLabels(chart);
        });
        H.addEvent(window, 'afterprint', function () {
          chart.setSize(chart._screenMediaWidth, chart.chartHeight, false);
          that.drawJackKnifeLabels(chart);
        });
      });

    }(Highcharts));
  }

  ngAfterViewInit() {

    this.dataService.getParts().subscribe(data => {

      if (data.status) {
        this.setMainParts(data.parts);
      }
    }, () => { }, () => { this.isPartsLoaded = true; });

    this.getCompanyTree();

  }

  selectReport(reportType) {
    if (this.report.type !== reportType) {
      this.report.name = null;
    }

    this.report.type = reportType;

    if (this.report.name === null) {
      switch (reportType) {
        case 'criticality': this.report.name = 'Reporte de Criticidad'; break;
        case 'jack-knife': this.report.name = 'Reporte Jack-Knife'; break;
      }
    }

    this.setStep('report-configuration');
  }

  generateReport(withRiskReduction = false) {

    if (!$('#report-config-form').validationEngine('validate')) { return; }

    UIkit.notification({
      message: 'Calculando...',
      status: 'success',
      pos: 'top-center',
      timeout: 2500
    });

    if (this.currentStep === 'report-configuration') {
      this.report.config.date_from = $('#cgs-date-from').val();
      this.report.config.date_to = $('#cgs-date-to').val();
    }

    // Reset reduccion de riesgo
    if (withRiskReduction) {
      this.report.config.risk_reduction.enabled = true;
    } else {
      this.report.config.risk_reduction.enabled = false;
      this.report.config.risk_reduction.value = null;
      this.toggleRiskReductionCols(true);
    }

    if (this.selectionMode === 'parts') {

      // Solo se necesitan las ids
      const selectedPartsIds = this.selectedMain.map(part => part.code);

      this.calculationStatus = 1;
      this.dataService.calculateRisksByParts(selectedPartsIds, this.report.config)
        .subscribe(data => {
          this.processReportResponse(data, withRiskReduction);
        },
          () => {

            this.calculationStatus = 0;
            UIkit.notification({
              status: 'danger',
              message: 'Ocurrió un error inesperado al obtener el reporte',
              pos: 'top-center',
              timeout: 2500
            });

          },
          () => {
            this.calculationStatus = 0;
          });

    } else {

      // Solo se necesitan las ids
      const selectedSubsystemsIds = this.currentNodes.map(node => {
        return node.data.subsystem_ref;
      });

      this.calculationStatus = 1;
      this.dataService.calculateRisks(selectedSubsystemsIds, this.report.config)
        .subscribe(data => {
          this.processReportResponse(data, withRiskReduction);
        },
          () => {

            this.calculationStatus = 0;
            UIkit.notification({
              status: 'danger',
              message: 'Ocurrió un error inesperado al obtener el reporte',
              pos: 'top-center',
              timeout: 2500
            });

          },
          () => {
            this.calculationStatus = 0;
          });
    }

  }

  processReportResponse(data, withRiskReduction) {

    if (data.status) {

      this.report.global_sr = data.global_rs; // Welp...
      this.report.global_fr = data.global_rf;

      // Se respaldan los datos originales pues pueden ser cambiados mediante interaccion con reporte
      data.parts_ranking.forEach(p => {
        p.original = {
          sr: p.stock_risk,
          fr: p.failure_risk,
          cr: p.criticality,
          sc: p.global_sector
        };
      });

      // Por defecto, todas las partes estan seleccionadas
      this.onSelect({ selected: data.parts_ranking }, false);
      this.setParts(data.parts_ranking);

      // Se habilita la vista de reporte
      this.setStep('report-display');

      // En caso de contener la reducción del riesgo, se muestran las columnas asociadas
      if (withRiskReduction) {
        this.columnsVisibility.stock_quantity_suggested.visible = true;
        this.columnsVisibility.cost_expected.visible = true;
      }

      // Si es un reporte Jack Knife, se dibuja el grafico
      if (this.report.type === 'jack-knife') {
        setTimeout(() => this.drawJackKnife(), 100); // Esperar por dom
      } else {
        this.columnsVisibility.sector_relative.visible = false; // Solo se muestra columna global
      }
    } else {
      UIkit.notification({
        status: 'danger',
        message: data.msg ? data.msg : 'Ocurrió un error al obtener el reporte',
        pos: 'top-center',
        timeout: 5000
      });
    }

    // Indicar que ya se hizo el cálculo
    this.calculationStatus = 0;
  }

  calculateRiskReduction() {

    const riskReduction = $('#report-risk-reduction-value').val();
    if (riskReduction.trim() === '' || isNaN(riskReduction)) {

      UIkit.notification({
        message: 'Ingrese Reducción de Riesgo a calcular',
        pos: 'top-center',
        status: 'danger',
        timeout: 5000
      });

      return;
    }

    this.generateReport(true);
  }

  toggleRiskReductionCols(forceHide = false) {

    const enabled = this.report.config.risk_reduction.enabled;

    if (forceHide || enabled) {
      this.columnsVisibility.stock_quantity_suggested.visible = false;
      this.columnsVisibility.cost_expected.visible = false;
    }
  }

  drawJackKnife() {
    console.log('drawJackKnife');
    const finalCategories = [];
    const series = [];
    const plotlines = [];
    const chartAxisType = this.chart.axisType;

    const that = this;

    let avgStockRisk = this.report.global_sr;
    let avgFailureRisk = this.report.global_fr;

    // Se ajustan los ejes de JackKnife
    if (this.adjustJackKnifeAxis) {
      avgStockRisk = this.selected.reduce((a, p) => a + p.stock_risk, 0) / this.selected.length;
      avgFailureRisk = this.selected.reduce((a, p) => a + p.failure_risk, 0) / this.selected.length;
    }

    // Se generan los puntos a graficar
    this.selected.forEach(p => {

      const point = {
        name: p.name,
        code: p.code,
        x: p.original.fr,
        y: p.original.sr,
        criticality: p.criticality
      };

      // Si el grafico es logaritmico, necesitamos corregir los menores a 1
      if (chartAxisType === 'logarithmic') {
        p.stock_risk = p.stock_risk <= 0 ? avgStockRisk : p.stock_risk;
        p.failure_risk = p.failure_risk <= 0 ? avgFailureRisk : p.failure_risk;
        p.criticality = p.stock_risk * p.failure_risk * p.qualitative_analysis_value;

        point.y = p.stock_risk;
        point.x = p.failure_risk;
        point.criticality = p.criticality;
      } else { // Si es lineal, recuperar cualquier cambio hecho por eje logaritmico
        p.stock_risk = p.original.sr;
        p.failure_risk = p.original.fr;
        p.criticality = p.original.cr;
      }

      p.sector = that.getJackKnifeSector(p.stock_risk, p.failure_risk, avgStockRisk, avgFailureRisk);

      series.push(point);
    });

    // Actualizar la tabla
    this.currentParts = [...this.currentParts];

    // Personalización para eje logarítmico
    const logOptions = chartAxisType === 'logarithmic' ? {
      xAxis: {
        title: {
          text: 'Riesgo de Falla'
        },
        min: undefined,
        type: chartAxisType,
        minorTickInterval: 0.1
      },
      yAxis: {
        title: {
          text: 'Riesgo de Stock out'
        },
        min: undefined,
        type: chartAxisType,
        minorTickInterval: 0.1
      }
    } : {};

    // Controlar errores con puntos highcharts
    Highcharts.error = function (code) {
      // See https://github.com/highcharts/highcharts/blob/master/errors/errors.xml
      // for error id's
      let errorMsg = 'Error al graficar';
      switch (code) {
        case 10: errorMsg = 'No se pueden graficar valores 0<br/> en ejes logarítmicos'; break;
        default: console.log('error hichcharts: cod. ', code);
      }

      if (that.errorLabel) {
        that.errorLabel.destroy();
        that.errorLabel = null;
      }

      const chart = Highcharts.charts[Highcharts.charts.length - 1];
      that.errorLabel = chart.renderer.text(errorMsg, 100, (chart.plotHeight / 2) - 10)
        .attr({
          fill: 'red',
          zIndex: 20
        })
        .add();
    };

    // Finalmente se grafica
    this.hcChart = new Highcharts.Chart($.extend({}, {
      chart: {
        renderTo: that.chart.container_id,
        defaultSeriesType: 'scatter',
        zoomType: 'xy',
        printWidth: 700,

        events: {
          redraw: function () {

            // Redraw Averages
            let avgSr = that.report.global_sr;
            let avgFr = that.report.global_fr;

            // Se ajustan los ejes de JackKnife
            if (that.adjustJackKnifeAxis) {
              const points = this.series[0].points;
              avgSr = points.reduce((a, p) => a + p.y, 0) / points.length;
              avgFr = points.reduce((a, p) => a + p.x, 0) / points.length;
            }

            this.xAxis[0].removePlotLine('plotline-x');
            this.xAxis[0].addPlotLine({
              label: {
                text: 'Avg. ' + numeral(avgFr).format('0.00')
              },
              color: '#FF4200', // Color value
              dashStyle: 'dash', // Style of the plot line. Default to solid
              value: avgFr, // Value of where the line will appear
              width: 1, // Width of the line,
              zIndex: 5,
              id: 'plotline-x'
            });

            this.yAxis[0].removePlotLine('plotline-y');
            this.yAxis[0].addPlotLine({
              label: {
                text: 'Avg. ' + numeral(avgSr).format('0.00'),
                align: 'right'
              },
              color: '#FF4200', // Color value
              dashStyle: 'dash', // Style of the plot line. Default to solid
              value: avgSr, // Value of where the line will appear
              width: 1, // Width of the line,
              zIndex: 5,
              id: 'plotline-y'
            });

          },
          load: function () {
            this.redraw();

            // Se dibujan las etiquetas JK
            that.drawJackKnifeLabels(this);

          },
          selection: function () {

            // Al hacer zoom se destruyen las etiquetas de jackknife
            that.chartLabels.forEach(n => {
              n.destroy();
            });
            that.chartLabels = [];

          }

        }
      },

      title: {
        text: ''
      },

      xAxis: {
        title: {
          enabled: true,
          text: 'Riesgo de Falla'
        },
        min: 0,
      },
      yAxis: {
        title: {
          text: 'Riesgo de Stock out'
        },
        min: 0
      },

      legend: {
        enabled: false
      },
      credits: {
        enabled: false
      },
      exporting: {
        enabled: false
      },

      boost: {
        useGPUTranslations: true,
        usePreAllocated: true
      },

      plotOptions: {
        series: {
          colorByPoint: true,
          turboThreshold: 1500
        },
        scatter: {
          marker: {
            radius: 3,
            states: {
              hover: {
                enabled: true
              }
            }
          },
          states: {
            hover: {
              marker: {
                enabled: false
              }
            }
          }
        }
      },
      series: [{
        data: series
      }],
      tooltip: {

        useHTML: true,
        shared: true,
        backgroundColor: 'rgba(0,0,0,0.75)',
        borderColor: 'rgba(0,0,0,0.75)',
        style: {
          color: '#ffffff',
        },
        formatter: function () {

          return `<table>
            <tr><th colspan="2"><div>${this.point.name}</div><div style="padding-bottom: 15px;">Cód: ${this.point.code}</div></th></tr>
            <tr><th>RF:</th><td>${numeral(this.x).format('0.[00]')}</td></tr>
            <tr><th>RS:</th><td>${numeral(this.y).format('0.[00]')} hrs</td></tr>
            <tr><th>Criticidad:</th><td>${numeral(this.point.criticality).format('0.[00]')}</td></tr>
            <tr><th></th><td></td></tr>
            </table>`;
        },
        followPointer: true
      }
    }, logOptions));

  }

  getJackKnifeSector(sr, fr, avgSr, avgFr) {
    if (fr <= avgFr) {
      return (sr <= avgSr) ? 'bot_left' : 'top_left';
    } else {
      return (sr <= avgSr) ? 'bot_right' : 'top_right';
    }
  }

  /**
   * Crea o actualiza las etiquetas utilizadas por jacknife
   * @param chart Highcharts chart
   */
  drawJackKnifeLabels(chart) {
    const r = chart.renderer,
      left = chart.plotLeft,
      top = chart.plotTop,
      h = chart.plotHeight,
      w = chart.plotWidth,
      colors = Highcharts.getOptions().colors,
      isoLinesCount = this.isoLinesCount;


    for (let i = 0; i < isoLinesCount; i++) {
      const offsetX = Math.round(w / isoLinesCount) * i;
      const offsetY = Math.round(h / isoLinesCount) * i;

      const startX = left + offsetX;
      const startY = top;

      const endX = w + left;
      const endY = h + top - offsetY;

      const isoLine = ['M', left + offsetX, top, 'C'];
      isoLine.push((startX * 1.1)); // punto de control curva bezier X inicial
      isoLine.push(startY + ((endY - startY) * 0.5)); // punto de control curva bezier Y inicial
      isoLine.push(startX + ((endX - startX) * 0.5)); // punto de control curva bezier X final
      isoLine.push(endY * 0.75); // punto de control curva bezier Y final
      isoLine.push(endX); // X coord final
      isoLine.push(endY); // Y coord final

      /*r.path(isoLine)
        .attr({
          'stroke-width': 0.5,
          stroke: 'red'
        })
        .add();*/
    }

    // Se remueven las etiquetas anteriores
    this.chartLabels.forEach(n => {
      n.destroy();
    });
    this.chartLabels = [];


    // Se agregan las etiquetas nuevas solo cuando no hay zoom
    if (!chart.resetZoomButton) {
      const padding = 15;
      this.chartLabels.push(r.text(this.chartSectors.top_left, left + padding, top + padding)
        .css({
          fontSize: '11px',
          color: '#FF4200'
        }).attr({ zIndex: 1 })
        .add()
      );
      this.chartLabels.push(r.text(this.chartSectors.top_right, left + w - 185, top + padding)
        .css({
          fontSize: '11px',
          color: '#FF4200',
          align: 'right'
        }).attr({ zIndex: 1 })
        .add()
      );
      this.chartLabels.push(r.text(this.chartSectors.bot_left, left + padding, top + h - padding / 2)
        .css({
          fontSize: '11px',
          color: '#FF4200'
        }).attr({ zIndex: 1 })
        .add()
      );
      this.chartLabels.push(r.text(this.chartSectors.bot_right, left + w - 115, top + h - padding / 2)
        .css({
          fontSize: '11px',
          color: '#FF4200',
          textAlign: 'right'
        }).attr({ zIndex: 1 })
        .add()
      );
    }

  }

  /**
     * Se obtienen los nodos del DLF y luego se genera el arbol
     */
  getCompanyTree() {

    if (this.markersList !== null) {
    } else {
      this.dataService.getCompanyTreeStructure()
        .subscribe(data => {

          const response = data;

          if (response['status'] == true) {
            this.markersList = response['markers_list'];
            this.generateCompanyTree(this.markersList, this.treeContainerId);
          }
        }, () => { }, () => { this.isCompanyTreeStructureLoaded = true; });
    }
  }

  /**
   * Se genera el arbol DLF y se configuran sus eventos
   * @param tree arbol de nodos del DLF
   * @param selector selector DOM donde se dibujara el arbol
   */
  generateCompanyTree(tree, selector) {

    console.log('generating in ' + selector);
    const IMG_URL = './assets/img';
    $(selector).jstree('destroy');
    $.jstree.defaults.checkbox.three_state = false;
    const parent = this;
    const treeTypes = {
      default: {
        icon: IMG_URL + '/jstree_icons/equip.png'
      },
      graph: {
        icon: IMG_URL + '/jstree_icons/corporation.png'
      },
      area: {
        icon: IMG_URL + '/jstree_icons/equipPlant.png'
      },
      linearmachine: {
        icon: IMG_URL + '/jstree_icons/line.png'
      },
      equipment: {
        icon: IMG_URL + '/jstree_icons/equip.png'
      },
      standbymachine: {
        icon: IMG_URL + '/jstree_icons/standby.png'
      },
      fractionmachine: {
        icon: IMG_URL + '/jstree_icons/fraction.png'
      },
      redundantmachine: {
        icon: IMG_URL + '/jstree_icons/redundant.png'
      },
      parallelmachine: {
        icon: IMG_URL + '/jstree_icons/parallel.png'
      },
      stockpile: {
        icon: IMG_URL + '/jstree_icons/stockpile.png'
      }
    };
    // Crear una instancia de js tree
    $(selector).jstree({
      'core': {
        data: tree,
        check_callback: true
      },
      types: treeTypes,
      state: { key: 'rmes-suite' },
      plugins: ['search', 'types', 'state', 'checkbox', 'contextmenu'],
      'contextmenu': {
        'items': function (node) {

          const t = $(selector).jstree(true);

          return {
            'view_details': {
              'separator_before': false,
              'separator_after': true,
              'label': 'Detalles',
              'action': function (obj) {
                const dialogHtml = `
                <div class="uk-padding">
                  <h3 class="uk-modal-title">${node.original.text}</h3>
                  <button class="uk-modal-close-full uk-close-large" type="button" uk-close></button>
                  <table class="uk-table uk-table-divider">
                    <tr><th>Nombre</th><td>${node.original.text}</td></tr>
                    <tr><th>Nickname</th><td>${node.data.nickname ? node.data.nickname : '<i>N/A</i>'}</td></tr>
                    <tr><th>Id</th><td>${node.data.subsystem_ref ? node.data.subsystem_ref : node.original.oid}</td></tr>
                  </table>
                </div>
                <div class="uk-modal-footer uk-text-right">
                  <button class="uk-button uk-button-primary uk-modal-close" type="button">Aceptar</button>
                </div>
                `;

                UIkit.modal.dialog(dialogHtml);

              }
            },
            'select_children': {
              'separator_before': false,
              'separator_after': false,
              'label': node.state.selected ? 'Deseleccionar hijos' : 'Seleccionar hijos',
              'action': function (obj) {

                if (node.state.selected) {
                  t.deselect_node(node.children, true); // No ejecuta eventos pues pueden ser muchos nodos
                  t.deselect_node(node.id);
                } else {
                  t.select_node(node.children, true); // No ejecuta eventos pues pueden ser muchos nodos
                  t.select_node(node.id);
                }

              }
            },
            'select_descendants': {
              'separator_before': false,
              'separator_after': true,
              'label': node.state.selected ? 'Deseleccionar todo' : 'Seleccionar todo',
              'action': function (obj) {

                if (node.state.selected) {
                  t.deselect_node(node.children_d, true); // No ejecuta eventos pues pueden ser muchos nodos
                  t.deselect_node(node.id);
                } else {
                  t.select_node(node.children_d, true); // No ejecuta eventos pues pueden ser muchos nodos
                  t.select_node(node.id);
                }

              }
            },
            'collapse_all': {
              'separator_before': false,
              'separator_after': false,
              'label': node.state.opened ? 'Colapsar todo' : 'Expandir todo',
              'action': function (obj) {

                const nodeChildren = node.children_d;
                if (node.state.opened) {
                  t.close_node(nodeChildren, null, nodeChildren.length < 100 ? true : false);
                  t.close_node(node, null, true);
                } else {
                  t.open_node(nodeChildren, null, nodeChildren.length < 100 ? true : false);
                  t.open_node(node, null, true);
                }

              }
            }
          };

        },
        'select_node': false
      }
    });

    const companyTree = $(selector).jstree(true);
    let to = null;
    $('#tree-search').keyup(function () {
      if (to) {
        clearTimeout(to);
      }
      to = setTimeout(function () {
        const v = $('#tree-search').val();
        if (v.length >= 3 || v.length === 0) {
          $(selector).jstree(true).search(v);
        }
      }, 250);
    });

    // Se asignan los eventos post carga del jstree para evitar multiples llamadas del plugin state
    $(selector).on('ready.jstree', function () {

      // Listener para click en elementos de jstree
      $(selector).on('changed.jstree', function (e, data) {

        const nodes = companyTree.get_selected(true);

        parent.setStep('report-selection');
        parent.currentNodes = nodes;

      });

      // Se ejecutan los eventos una vez para actualizar la app
      $(selector).trigger('changed.jstree');
    });


  }

  setStep(step) {

    this.currentStep = step;

    // Se configuran los campos datepicker
    if (this.currentStep === 'report-configuration') {
      // wait for dom
      setTimeout(() => this.setupDatepickerFields(), 100);
    }
  }

  selectionAvailable() {
    if (this.selectionMode === 'assets' && this.currentNodes && this.currentNodes.length > 0) {
      return true;
    }

    if (this.selectionMode === 'parts' && this.selectedMain.length > 0) {
      return true;
    }

    return false;
  }

  /**
   * Deben corregirse las fechas siguientes segun el input
   * @param dateType
   * @param e event
   */
  onDateChange() {


    const $dateFrom = $('#cgs-date-from');
    const $dateTo = $('#cgs-date-to');
    // const $dateHorizon = $('#cgs-date-horizon');

    const fromDateMoment = moment($dateFrom.val());
    let toDateMoment = moment($dateTo.val());
    // const horizonDateMoment = moment($dateHorizon.val());

    if (fromDateMoment.diff(toDateMoment) > 0) {
      console.log(fromDateMoment.format('YYYY-MM-DD'));

      // Se corrige fecha to
      this.report.config.date_to = fromDateMoment.format('YYYY-MM-DD');
      toDateMoment = fromDateMoment;
    }

    // El horizonte de analisis debe ser al menos 1 mes
    /* if (toDateMoment.add(1, 'months').diff(horizonDateMoment) > 0) {
       console.log('d');
       console.log(toDateMoment.format('YYYY-MM-DD'));
       // this.report.config.horizon = toDateMoment.format('YYYY-MM-DD'); no pesca?
       $dateHorizon.val(toDateMoment.format('YYYY-MM-DD'));
     }*/
  }


  setupDatepickerFields() {

    // Esperar update de DOM para aplicar selector de fecha/hora
    setTimeout(() => {
      $('.datetimepicker:not(.datetimepicker-initialized)')
        .addClass('datetimepicker-initialized')
        .datetimepicker({
          timepicker: false,
          format: 'Y-m-d'
        });
    }, 250);
  }

  hexToRgb(hex) {
    // Expand shorthand form (e.g. "03F") to full form (e.g. "0033FF")
    const shorthandRegex = /^#?([a-f\d])([a-f\d])([a-f\d])$/i;
    hex = hex.replace(shorthandRegex, function (m, r, g, b) {
      return r + r + g + g + b + b;
    });

    const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
    return result ? {
      r: parseInt(result[1], 16),
      g: parseInt(result[2], 16),
      b: parseInt(result[3], 16)
    } : null;
  }

  changeSelectionMode(selectionMode) {
    if (selectionMode === 'assets') {
      this.getCompanyTree();
    }
    this.selectionMode = selectionMode;
    this.currentStep = 'report-selection';
  }

  exportReport(exportType) {

    if (this.selected.length > 100) {

      UIkit.modal.confirm(`Está por solicitar un reporte con una gran cantidad de repuestos. Esto podría tardar varios segundos.
      <br>
      Está seguro que desea continuar?
      `)
        .then(() => {
          this.doExport(exportType);
        }, () => {
          console.log('Rejected.');
        });

    } else {
      this.doExport(exportType);
    }

  }

  doExport(exportType) {

    const showNotification = exportType === 'pdf' ? false : true;
    const timeout = exportType === 'server' ? false : true;

    if (showNotification) {
      if (timeout) {
        UIkit.notification({
          message: 'Generando Descarga...',
          pos: 'top-center',
          status: 'success',
          timeout: 5000
        });
      } else {
        UIkit.notification({
          message: '<div uk-spinner></div>  Generando Descarga...',
          pos: 'top-center',
          status: 'success',
          timeout: 0
        });
      }
    }

    switch (exportType) {
      case 'server': setTimeout(() => { this.exportServer(); }, 1000); break; // Permitir un seg para levantar la notificacion sin lag
      case 'xls': this.exportExcel(); break;
      case 'chart': this.hcChart.exportChart(); break;
    }

  }

  /**
   * Inicia generacion y descarga de reporte PDF.
   * Se envian todos los datos necesarios al servidor el cual utiliza TCPDF para generar el reporte
   */
  private exportServer() {
    const svg = this.report.type === 'jack-knife' ? this.hcChart.getSVG() : null;
    this.report.chart.svg = svg ? svg : null;
    this.report.results = this.selected;
    this.report.chart_sectors = this.chartSectors;
    this.report.visible_columns = this.columnsVisibility;
    this.report.date = moment().format('YYYY-MM-DD h:mm:ss a');

    // De momento angular no ofrece una solucion simple para descargar pdf mediante Ajax
    const req = new XMLHttpRequest();
    req.open('POST', this.dataService.backendUrl + 'pdf_generation/templates/template_sprisk.php', true);
    req.responseType = 'blob';

    req.onload = function (event) {
      UIkit.notification.closeAll();
      const blob = req.response;
      const link = document.createElement('a');
      link.href = window.URL.createObjectURL(blob);
      link.download = 'Reporte SPRISK ' + moment().format('YYYY-MM-DD') + '.pdf';
      link.click();
    };

    req.send(JSON.stringify(this.report));
  }

  /**
   * Se exporta archivo excel con todos los repuestos filtrados
   */
  private exportExcel() {

    /* generate workbook and add the worksheet */
    const wb: XLSX.WorkBook = XLSX.utils.book_new();
    const xlsxName = this.report.name + ' ' + moment().format('YYYY-MM-DD');

    const partsData: XLSX.WorkSheet = this.getExportableSheet('#cgs-report-criticality-table');
    XLSX.utils.book_append_sheet(wb, partsData, 'Datos_reporte');

    /* save to file */
    const wbout: string = XLSX.write(wb, { bookType: 'xlsx', type: 'binary' });
    saveAs(new Blob([this.dataService.s2ab(wbout)]), xlsxName + '.xlsx');
  }

  updateChart() {
    this.drawJackKnife();
  }

  updateMarkerSize(size) {

    this.hcChart.update({
      plotOptions: {
        series: {
          marker: {
            radius: size
          }
        }
      }
    });
  }

  /**
   * Obtiene todos los datos a exportar en la hoja
   */
  getExportableSheet(elementSelector): XLSX.WorkSheet {

    const tableArray = [];

    /*

      {
        name: { id: 'name', visible: true, name: 'Nombre' },
        code: { id: 'code', visible: true, name: 'Código' },
        stock_quantity: { id: 'stock_quantity', visible: true, name: 'Stock' },
        stock_quantity_suggested: { id: 'stock_quantity_suggested', visible: false, name: 'Stock Sugerido' },
        cost: { id: 'cost', visible: true, name: 'Costo' },
        cost_expected: { id: 'cost_expected', visible: false, name: 'Costo Esperado' },
        stock_risk: { id: 'stock_risk', visible: true, name: 'RS' },
        failure_risk: { id: 'failure_risk', visible: true, name: 'RF' },
        criticality: { id: 'criticality', visible: true, name: 'Criticidad' },
        sector_global: { id: 'sector_global', visible: true, name: 'Sector Global' },
        sector_relative: { id: 'sector_relative', visible: true, name: 'Sector Relativo' }
      }

    */

    // Se obtiene el header
    const header = [];
    const headerKeys = [];
    Object.keys(this.columnsVisibility).forEach(key => {
      if (this.columnsVisibility[key].visible) {
        header.push(this.columnsVisibility[key].name);

        if (key === 'sector_global') {
          key = 'global_sector';
        } else if (key === 'sector_relative') {
          key = 'sector';
        }

        headerKeys.push(key);
      }
    });

    tableArray.push(header);

    this.selected.forEach(e => {

      const filteredRow = [];
      headerKeys.forEach(colKey => {

        if (colKey === 'sector' || colKey === 'global_sector') {
          filteredRow.push(this.chartSectors[e[colKey]]);
        } else {
          filteredRow.push(e[colKey]);
        }

      });

      tableArray.push(filteredRow);

    });
    /*
        $(elementSelector + ' datatable-header, ' + elementSelector + ' datatable-body datatable-body-row').each(function (i, e) {
    
          const row = [];
          const tableData = $(this).find(i > 0 ? 'datatable-body-cell.cgs-export-value' : 'datatable-header-cell.cgs-export-value');
          if (tableData.length > 0) {
            tableData.each(function () {
    
              // Se extrae el valor del input o el texto del campo
              const exportableValue = $(this);
    
              let auxValue: any = '';
              auxValue = $(exportableValue).text();
    
              auxValue = auxValue
                .split('\t').map(el => el.trim()).join(' ')
                .split('\n').map(el => el.trim()).join(' ')
                .split('\r').map(el => el.trim()).join(' ');
    
              if (auxValue !== '' && !isNaN(auxValue)) {
                auxValue = parseFloat(auxValue);
              }
    
              row.push(auxValue);
            });
    
            tableArray.push(row);
          }
        });
    */
    return XLSX.utils.aoa_to_sheet(tableArray);
  }

  getReportModeName() {

    let name = '';
    this.report.config.mode.modes.forEach(mode => {
      if (mode.id === this.report.config.mode.selected) {
        name = mode.name;
      }
    });

    return name;
  }

  setMainParts(parts) {

    this.parts = parts;

    // cache our list for future searches
    this.tempMain = [...parts];
  }

  setParts(parts) {

    this.currentParts = parts;

    // cache our list for future searches
    this.temp = [...parts];
  }

  onSelectMain({ selected }) {
    this.selectedMain.splice(0, this.selectedMain.length);
    this.selectedMain.push(...selected);
  }

  onSelect({ selected }, redrawChart = true) {

    this.selected.splice(0, this.selected.length);
    this.selected.push(...selected);

    if (redrawChart) {
      this.updateChart();
    }
  }

  updateSectorVisibility(sector) {
    const visibility = !this.chartSectorsVisibility[sector];
    this.chartSectorsVisibility[sector] = visibility;

    const filteredList = this.temp.filter(part => {
      return this.chartSectorsVisibility[part.sector];
    });

    this.onSelect({ selected: filteredList });
  }

  updateFilter(event) {
    const val = event.target.value.toLowerCase().trim();

    // filter our data
    const temp = this.temp.filter(d => {
      if (!val) { // return all rows if empty search
        return true;
      }

      for (const key of this.searchFields) { // Se busca match en cada campo filtrable

        switch (typeof d[key]) {
          case 'string':  // Para strings es case insensitive
            if (d[key] && d[key].toLowerCase().indexOf(val) !== -1) {
              return true;
            }
            break;
          case 'number':
            if (d[key] + '' === val) {
              return true;
            }
            break;
          default:

            if (d[key] === val) {
              return true;
            }

        }

      }

      return false;
    });

    // update the rows
    this.currentParts = temp;
    // Whenever the filter changes, always go back to the first page
    if (this.partsTable) {
      this.partsTable.offset = 0;
    }
  }

  updateMainFilter(event) {
    const val = event.target.value.toLowerCase().trim();

    // filter our data
    const tempMain = this.tempMain.filter(d => {
      if (!val) { // return all rows if empty search
        return true;
      }

      for (const key of this.searchFieldsMain) { // Se busca match en cada campo filtrable

        switch (typeof d[key]) {
          case 'string':  // Para strings es case insensitive
            if (d[key] && d[key].toLowerCase().indexOf(val) !== -1) {
              return true;
            }
            break;
          case 'number':
            if (d[key] + '' === val) {
              return true;
            }
            break;
          default:

            if (d[key] === val) {
              return true;
            }

        }

      }

      return false;
    });

    // update the rows
    this.parts = tempMain;
    // Whenever the filter changes, always go back to the first page
    if (this.mainPartsTable) {
      this.mainPartsTable.offset = 0;
    }
  }


  columnVisToggle(col) {
    col.visible = !col.visible;
  }

  columnVisIsChecked(col) {
    return col.visible;
  }
}
