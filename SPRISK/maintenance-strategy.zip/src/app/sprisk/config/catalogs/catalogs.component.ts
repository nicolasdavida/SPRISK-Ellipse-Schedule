import { DataService } from './../../../shared/services/data.service';
import { Router } from '@angular/router';
import { Component, OnInit, ViewChild } from '@angular/core';
import { DatatableComponent } from '@swimlane/ngx-datatable';

@Component({
  selector: 'app-catalogs',
  templateUrl: './catalogs.component.html',
  styleUrls: ['./catalogs.component.scss']
})
export class CatalogsComponent implements OnInit {

  catalogs = null;
  importExpectedColumns = [
    { id: 'name', name: 'Nombre', required: true },
    { id: 'code', name: 'Código', required: true },
    { id: 'description', name: 'Descripción', required: false }
  ];
  importUrl: string;


  // Variables de tabla
  @ViewChild(DatatableComponent) catalogsTable: DatatableComponent;
  selected = [];
  temp = [];
  searchFields = ['name', 'code', 'description'];

  constructor(private router: Router, private dataService: DataService) { }


  ngOnInit() {

    this.dataService.getCatalogs().subscribe(data => {
      if (data.status) {
        this.setCatalogs(data.catalogs);
      }
    });

    this.importUrl = this.dataService.getImportPath('catalogs');
  }

  addCatalog() {
    this.router.navigate(['/sprisk/config/catalog', 0]);
  }

  editCatalog(catalogCode) {
    this.router.navigate(['/sprisk/config/catalog', catalogCode]);
  }

  exportCatalogs() {

    const exportData = [['Nombre', 'Código', 'Descripción', 'Equipos', 'Modos de Falla']];

    this.temp.forEach(c => {
      exportData.push([c.name, c.code, c.description, c.subsystems.length, c.failure_modes.length]);
    });

    this.dataService.exportExcel(exportData, 'Catálogos', 'Catálogos');
  }

  onImportResult(importResult) {

    if (importResult.status && importResult.catalogs) {
      this.setCatalogs(importResult.catalogs);
    }
  }

  setCatalogs(catalogs) {

    this.catalogs = catalogs;

    // cache our list for future searches
    this.temp = [...catalogs];
  }

  /** Funciones relativas a la tabla */
  onSelect({ selected }) {
    this.selected.splice(0, this.selected.length);
    this.selected.push(...selected);
  }

  updateFilter(event) {
    const val = event.target.value.toLowerCase().trim();

    // filter our data
    const temp = this.temp.filter(d => {
      if (!val) { // return all rows if empty search
        return true;
      }

      for (const key of this.searchFields) { // Se busca match en cada campo filtrable

        switch (typeof d[key]) {
          case 'string':  // Para strings es case insensitive
            if (d[key] && d[key].toLowerCase().indexOf(val) !== -1) {
              return true;
            }
            break;
          case 'number':
            if (d[key] + '' === val) {
              return true;
            }
            break;
          default:

            if (d[key] === val) {
              return true;
            }

        }

      }

      return false;
    });

    // update the rows
    this.catalogs = temp;
    // Whenever the filter changes, always go back to the first page
    if (this.catalogsTable) {
      this.catalogsTable.offset = 0;
    }
  }
}
