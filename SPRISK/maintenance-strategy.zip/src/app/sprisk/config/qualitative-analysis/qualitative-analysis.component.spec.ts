import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { QualitativeAnalysisComponent } from './qualitative-analysis.component';

describe('QualitativeAnalysisComponent', () => {
  let component: QualitativeAnalysisComponent;
  let fixture: ComponentFixture<QualitativeAnalysisComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ QualitativeAnalysisComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(QualitativeAnalysisComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
