import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DataService } from './../../../shared/services/data.service';

declare const $: any;
declare const UIkit: any;

@Component({
  selector: 'app-qualitative-analysis',
  templateUrl: './qualitative-analysis.component.html',
  styleUrls: ['./qualitative-analysis.component.scss']
})
export class QualitativeAnalysisComponent implements OnInit {

  qualitativeAnalysis = [];
  balanceToggle = true;

  isLoaded = false;
  constructor(private dataService: DataService, private router: Router) { }

  ngOnInit() {

    this.dataService.getQualitativeAnalysisVariables().subscribe(data => {
      if (data.status) {

        this.qualitativeAnalysis = data.qualitative_analysis_variables;
        this.isLoaded = true;

      }
    },
      () => {
        UIkit.notification({
          message: 'No fue posible obtener las variables desde el servidor',
          status: 'danger',
          pos: 'top-center',
          timeout: 5000
        });
      });

  }

  saveQualitativeAnalysisVariables() {
    this.dataService.saveQualitativeAnalysisVariables(this.qualitativeAnalysis).subscribe(data => {

      if (data.status) {

        this.qualitativeAnalysis = data.qualitative_analysis_variables;

        UIkit.notification({
          message: 'Las variables han sido ha sido guardadas',
          status: 'success',
          pos: 'top-center',
          timeout: 5000
        });
      } else {

        UIkit.notification({
          message: 'Ocurrió un error al guardar las variables',
          status: 'danger',
          pos: 'top-center',
          timeout: 5000
        });
      }
    },
      () => {

        UIkit.notification({
          message: 'Ocurrió un error inesperado al guardar las variables',
          status: 'danger',
          pos: 'top-center',
          timeout: 5000
        });
      });

  }

  addQualitativeAnalysisRow() {

    const qa = {
      id: null,
      name: '',
      weight: 0,
      date_created: null,
      date_updated: null,
      status: true
    };

    this.qualitativeAnalysis.push(qa);

    if (this.balanceToggle) {
      this.balanceWeights();
    }
  }

  balanceWeights() {

    const enabledQas = this.qualitativeAnalysis.filter(qa => qa.status);
    if (enabledQas.length === 0) {
      return;
    }

    const totalWeight = 100;
    const avgWeight = Math.floor(totalWeight * 10 / enabledQas.length) / 10;

    enabledQas.forEach((qa, i) => {
      if (i !== (enabledQas.length - 1)) { // En todos los elementos, exceptuando el ultimo
        qa.weight = avgWeight;
      }
      else { // Ultimo elemento se le asigna el total restante
        qa.weight = Math.floor((totalWeight - (enabledQas.length - 1) * avgWeight) * 10) / 10;
      }

    });

  }

  deleteQualitativeAnalysisRow(qa) {

    UIkit.modal.confirm('Está seguro que desea eliminar esta variable de análisis cuantitativo?')
      .then(() => {

        qa.status = false;
        if (qa.id === null) { // no existe en db, se saca del arreglo pues no es necesario que la db lo vea

          const index = this.qualitativeAnalysis.indexOf(qa);
          if (index !== -1) {
            this.qualitativeAnalysis.splice(index, 1);
          }

        }

        if (this.balanceToggle) {
          this.balanceWeights();
        }

      }, () => {
        console.log('Rejected.');
      });

  }

  qualitativeAnalysisTotal() {
    const enabledQas = this.qualitativeAnalysis.filter(qa => qa.status);
    const total = enabledQas.reduce((a, b) => {

      if (!isNaN(b.weight)) {
        return a + parseFloat(b.weight);
      }

      return a;
    }, 0);

    return Math.round((total) * 10) / 10;
  }
}
