import { Router } from '@angular/router';
import { DataService } from './../../../shared/services/data.service';
import { Component, OnInit, AfterViewInit, ViewChild } from '@angular/core';
import { DatatableComponent } from '@swimlane/ngx-datatable';
import { DecimalPipe } from '@angular/common';

declare const UIkit: any;
declare const numeral: any;
declare const $: any;

@Component({
  selector: 'app-parts-list',
  templateUrl: './parts-list.component.html',
  styleUrls: ['./parts-list.component.scss']
})

export class PartsListComponent implements OnInit {

  numeral = numeral;
  parts: any[] = null;

  // Repuesto virtual para asignar analisis cualitativo
  part: any = {

    qualitative_analysis: {
      value: 1,
      mode: 'manual',
      data: null
    }

  };


  importExpectedColumns = [
    { id: 'code', name: 'Código', required: true },
    { id: 'name', name: 'Nombre', required: true },
    { id: 'description', name: 'Descripción', required: false },
    { id: 'erp_code', name: 'Cód. ERP', required: false },
    { id: 'part_number', name: 'No. Parte', required: false },
    { id: 'category_code', name: 'Cód. Categoría', required: false },
    { id: 'cost', name: 'Costo', required: false },
    { id: 'component_type_code', name: 'Cód. Tipo Componente', required: false },
    { id: 'component_type', name: 'Tipo Componente', required: false },
    { id: 'stock_quantity', name: 'Stock', required: true },
    { id: 'lead_time_buy', name: 'Lead Time Compra', required: true },
    { id: 'lead_time_storage', name: 'Lead Time Almac.', required: true },
    { id: 'observations', name: 'Observaciones', required: false },
    { id: 'qualitative_analysis', name: 'Análisis Cualitativo', required: false }
  ];
  importUrl = '';

  // Variables de tabla
  @ViewChild(DatatableComponent) partsTable: DatatableComponent;
  selected = [];
  temp = [];
  searchFields = ['name', 'code', 'erp_code', 'description', 'observations'];

  qualitativeModalOpen = false;
  constructor(private router: Router, private dataService: DataService, private decimalPipe: DecimalPipe) { }

  qualitativeAnalysisVariables = [];

  ngOnInit() {

    // Se obtiene listado de todas las partes
    this.dataService.getParts().subscribe(data => {

      if (data.status) {
        this.setParts(data.parts);
      }
    });

    // Se obtienen las variables de analisis cualitativo
    this.dataService.getQualitativeAnalysisVariables()
      .subscribe(data => {
        if (data.status) {

          this.qualitativeAnalysisVariables = data.qualitative_analysis_variables;
        }
      });

    this.importUrl = this.dataService.getImportPath('parts');

  }

  editPart(partCode) {
    this.router.navigate(['/sprisk/config/part/', partCode]);
  }

  addPart() {
    this.router.navigate(['/sprisk/config/part/']);
  }

  exportParts() {

    const currentLocale = this.dataService.getAppLocale();
    const localeList = [currentLocale.locale];
    if (currentLocale.fallback) {
      localeList.push(currentLocale.fallback);
    }

    const exportData = [
      ['Nombre',
        'Código',
        'Análisis Cualitativo',
        'Cód. ERP',
        'Cód. Categoría',
        'Cód. Tipo Componente',
        'Stock',
        'Descripción',
        'Número de Parte',
        'Costo',
        'Tipo Componente',
        'Lead Time Compra',
        'Lead Time Almacen',
        'Observaciones']
    ];

    this.temp.forEach(p => {

      exportData.push([
        p.name,
        p.code,
        parseFloat(p.qualitative_analysis.value).toLocaleString(localeList),
        p.erp_code,
        p.category_code,
        p.component_type_code,
        p.stock_quantity,
        p.description,
        p.part_number,
        parseFloat(p.cost).toLocaleString(localeList),
        p.component_type,
        p.lead_time_buy,
        p.lead_time_storage,
        p.observations]);

    });

    this.dataService.exportExcel(exportData, 'Repuestos', 'Repuestos');
  }

  onImportResult(importResult) {

    if (importResult.status && importResult.parts) {
      this.setParts(importResult.parts);
    }
  }

  setParts(parts) {

    this.parts = parts;

    // cache our list for future searches
    this.temp = [...parts];
  }

  /** Funciones relativas a la tabla */
  onMassiveSelectionUpdate(selection) {

    switch (selection) {
      case 'assign-cualitative-analysis':
        this.qualitativeModalOpen = true;
        UIkit.modal('#qualitative-analysis-modal').show();
        break;

      case 'delete':
        this.deleteMassParts();
        break;
    }

    $('#massive-selection-actions').val(null);
  }

  onSelect({ selected }) {
    this.selected.splice(0, this.selected.length);
    this.selected.push(...selected);
  }

  /**
   * No fue posible realizar two-way binding con los checkbox de ngx-datatable
  removeFromSelection(element) {
    const index = this.selected.indexOf(element);
    if (index !== -1) {
      this.selected.splice(index, 1);
    }

    $('ngx-datatable .ngx-cgs-checkbox').first().trigger('change');
  }*/

  updateFilter(event) {
    const val = event.target.value.toLowerCase().trim();

    // filter our data
    const temp = this.temp.filter(d => {
      if (!val) { // return all rows if empty search
        return true;
      }

      for (const key of this.searchFields) { // Se busca match en cada campo filtrable

        switch (typeof d[key]) {
          case 'string':  // Para strings es case insensitive
            if (d[key] && d[key].toLowerCase().indexOf(val) !== -1) {
              return true;
            }
            break;
          case 'number':
            if (d[key] + '' === val) {
              return true;
            }
            break;
          default:

            if (d[key] === val) {
              return true;
            }

        }

      }

      return false;
    });

    // update the rows
    this.parts = temp;
    // Whenever the filter changes, always go back to the first page
    if (this.partsTable) {
      this.partsTable.offset = 0;
    }
  }

  deleteMassParts() {

    if (this.selected.length === 0) {
      return;
    }

    UIkit.modal.confirm('Está seguro que desea eliminar ' + this.selected.length + ' repuestos?', { stack: true })
      .then(() => {

        this.dataService.deleteMassParts(this.selected)
          .subscribe(data => {

            if (data.status) {

              UIkit.notification({
                message: 'Se han borrado los repuestos exitósamente',
                status: 'success',
                timeout: 5000
              });

              // Se retiran todos los repuestos del listado de repuestos
              this.selected.forEach(part => {
                const index = this.temp.indexOf(part);
                if (index !== -1) {
                  this.temp.splice(index, 1);
                }
              });
              this.selected.splice(0, this.selected.length);

              this.setParts(this.temp);

            } else {

              UIkit.notification({
                message: 'Ocurrió un error al realizar los cambios',
                status: 'danger',
                timeout: 5000
              });

            }

          }, () => {

            UIkit.notification({
              message: 'Ocurrió un error inesperado al realizar los cambios',
              status: 'danger',
              timeout: 5000
            });

          });

      });
  }

  saveMassQualitativeAnalysis() {

    if (this.selected.length === 0) {
      return;
    }

    const auxSelection = JSON.parse(JSON.stringify(this.selected));
    auxSelection.forEach(part => {
      part.qualitative_analysis = this.part.qualitative_analysis;
    });

    this.dataService.saveMassQualitativeAnalysis(auxSelection)
      .subscribe(data => {

        if (data.status) {

          UIkit.notification({
            message: 'Los cambios han sido aplicados exitósamente',
            status: 'success',
            pos: 'top-center',
            timeout: 5000
          });

          this.selected.forEach(part => {
            part.qualitative_analysis = JSON.parse(JSON.stringify(this.part.qualitative_analysis));
          });

          this.parts = [...this.parts];
          UIkit.modal('#qualitative-analysis-modal').hide();

        } else {

          UIkit.notification({
            message: 'Ocurrió un error al realizar los cambios',
            status: 'danger',
            pos: 'top-center',
            timeout: 5000
          });

        }

      }, () => {

        UIkit.notification({
          message: 'Ocurrió un error inesperado al realizar los cambios',
          status: 'danger',
          pos: 'top-center',
          timeout: 5000
        });

      });
  }

  setQualitativeAnalysisEditionMode(mode) {

    if (mode === 'manual') {
      this.part.qualitative_analysis.data = null;
    } else {
      this.part.qualitative_analysis.data = this.normalizeQualitativeAnalysis([]);
      this.updateQualitativeAnalysisValue();
    }

    this.part.qualitative_analysis.mode = mode;
  }

  normalizeQualitativeAnalysis(qualitativeAnalysis) {

    if (qualitativeAnalysis === null) {
      return null;
    }

    const qualitativeAnalysisData = [];

    this.qualitativeAnalysisVariables.forEach(qav => {

      qav.value = 1; // Valor por defecto

      qualitativeAnalysis.forEach(qa => {
        if (qav.id == qa.type_id && !isNaN(qa.value)) {
          qav.value = qa.value;
        }

      });

      qualitativeAnalysisData.push(qav);

    });

    return qualitativeAnalysisData;
  }

  updateQualitativeAnalysisValue() {

    let qaValue = 0;

    this.part.qualitative_analysis.data.forEach(qa => {

      // Asegurar que valor no se escapa de los limites
      qa.value = Math.round(Math.max(qa.value, 1));
      qa.value = Math.min(qa.value, 5);

      if (qa.weight !== null && !isNaN(qa.weight) && qa.value !== null && !isNaN(qa.value)) {

        const weight = parseFloat(qa.weight) / 100;
        const value = parseFloat(qa.value);
        qaValue += weight * value;
      }
    });


    this.part.qualitative_analysis.value = Math.max(1, Math.round(qaValue * 100) / 100);
  }
}
