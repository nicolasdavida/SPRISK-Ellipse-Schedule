import { DatatableComponent } from '@swimlane/ngx-datatable';
import { DataService } from './../../../shared/services/data.service';
import { Component, OnInit, OnDestroy, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

declare const $: any;
declare const UIkit: any;

@Component({
  selector: 'app-failure-mode',
  templateUrl: './failure-mode.component.html',
  styleUrls: ['./failure-mode.component.scss']
})

export class FailureModeComponent implements OnInit, OnDestroy {

  failureMode: any = {
    id: null,
    code: '',
    name: '',
    type: 0,
    date_created: null,
    date_updated: null,
    status: true,

    parts: []
  };

  isLoaded = true;
  availableParts: any = null;
  failureModeTypes: any = [];


  // Variables de tabla Modal
  @ViewChild(DatatableComponent) partsTable: DatatableComponent;
  selected = [];
  temp = [];
  searchFields = ['name', 'code', 'erp_code', 'part_number'];

  // Variables de tabla de partes asignadas
  @ViewChild(DatatableComponent) subsystemPartsTable: DatatableComponent;
  subsystemPartsSelected = [];
  subsystemPartsTemp = [];


  private paramSub: any;
  partsModalSeen = false;
  constructor(private router: Router, private route: ActivatedRoute, private dataService: DataService) { }

  ngOnInit() {

    this.paramSub = this.route.params.subscribe(params => {
      const fmId = +params['id'];

      // Hay parametro valido esperar carga antes de mostrar pantalla
      if (fmId && !isNaN(fmId) && fmId > 0) {
        this.isLoaded = false;
      }

      // Se obtiene listado de todas las partes
      this.dataService.getParts().subscribe(data => {
        if (data.status) {
          this.setParts(data.parts);
        }
      });

      // Se obtiene listado de todos los tipos de modo de fallo
      this.dataService.getFailureModeTypes().subscribe(data => {

        if (data.status) {
          this.failureModeTypes = data.failure_mode_types;
        } else {
          UIkit.notification({
            message: 'Ha ocurrido un error inesperado al obtener los tipos de modo de falla',
            status: 'danger',
            pos: 'top-center',
            timeout: 5000
          });
        }
      },
        data => {
          UIkit.notification({
            message: 'Ha ocurrido un error inesperado al obtener los tipos de modo de falla',
            status: 'danger',
            pos: 'top-center',
            timeout: 5000
          });
        },
        () => {

          // Finalmente se obtiene el modo de falla
          if (fmId && !isNaN(fmId) && fmId > 0) {
            this.getFailureMode(fmId);
          }
        }
      );

    });

  }

  ngOnDestroy() {
    this.paramSub.unsubscribe();
  }

  getFailureMode(failureModeId) {
    this.dataService.getFailureMode(failureModeId).subscribe(data => {

      if (data.status) {

        /* if (data.failure_mode.parts) {
          // Normalizar a modelo angular
          data.failure_mode.parts = this.normalizeFailureModeParts(data.failure_mode.parts);
        }*/

        this.failureMode = data.failure_mode;
        this.onSelect({ selected: this.failureMode.parts });

        this.isLoaded = true;

      }
    },
      data => {
        UIkit.notification({
          message: 'Ha ocurrido un error inesperado al cargar el modo de falla',
          status: 'danger',
          pos: 'top-center',
          timeout: 5000
        });
      });
  }

  saveFailureMode() {

    if(!$("#main-form").validationEngine('validate')) {return};

    this.failureMode.parts = this.selected;
    this.dataService.saveFailureMode(this.failureMode).subscribe(data => {

      if (data.status) {
        this.failureMode = data.failure_mode;

        UIkit.notification({
          message: 'Modo de falla ha sido guardado',
          status: 'success',
          pos: 'top-center',
          timeout: 5000
        });
      } else {
        UIkit.notification({
          message: 'Ha ocurrido un error al guardar el modo de falla',
          status: 'danger',
          pos: 'top-center',
          timeout: 5000
        });
      }
    },
      data => {
        UIkit.notification({
          message: 'Ha ocurrido un error inesperado al guardar el modo de falla',
          status: 'danger',
          pos: 'top-center',
          timeout: 5000
        });
      });
  }

  deleteFailureMode() {

    UIkit.modal.confirm('Está seguro que desea eliminar este modo de falla?', { stack: true })
      .then(() => {

        if (this.failureMode.id) {
          this.dataService.deleteFailureMode(this.failureMode.id).subscribe(data => {

            if (data.status) {

              UIkit.notification({
                message: 'Modo de falla ha sido borrado',
                status: 'success',
                pos: 'top-center',
                timeout: 5000
              });
            } else {
              UIkit.notification({
                message: 'Ha ocurrido un error al borrar el modo de falla',
                status: 'danger',
                pos: 'top-center',
                timeout: 5000
              });
            }

          },
            data => {
              UIkit.notification({
                message: 'Ha ocurrido un error inesperado al borrar el modo de falla',
                status: 'danger',
                pos: 'top-center',
                timeout: 5000
              });
            });
        }

        this.router.navigate(['/sprisk/config/failure-modes/']);

      }, () => {
        console.log('Rejected.');
      });
  }

  /*normalizeFailureModeParts(failureModeParts) {
    const fmParts = [];

    failureModeParts.forEach(fmp => {

      for (let i = 0; i < this.availableParts.length; i++) {
        const part = this.availableParts[i];
        if (fmp.code === part.code) {

          part.checked = true;
          part.fmp_checked = false;
          fmParts.push(part);
        }
      }
    });

    return fmParts;
  }*/
  addFailureModeTypeRow() {

    const failureModeType = {
      id: null,
      code: '',
      name: '',
      date_created: null,
      date_updated: null,
      checked: false,
      status: true
    };

    this.failureModeTypes.push(failureModeType);
  }

  deleteFailureModeType(fmt) {

    UIkit.modal.confirm('Está seguro que desea eliminar este tipo de modo de falla?', { stack: true })
      .then(() => {
        fmt.status = false;
        fmt.checked = false;
      }, () => {
        console.log('Rejected.');
      });
  }

  deleteFailureModeTypeRows() {


    if (this.failureModeTypes.length === 0) {
      return;
    }

    UIkit.modal.confirm('Está seguro que desea eliminar estos tipos de modo de falla?', { stack: true })
      .then(() => {

        this.failureModeTypes.forEach(fmt => {

          if (fmt.checked) {
            fmt.status = false;
            fmt.checked = false;
          }

        });
      }, () => {
        console.log('Rejected.');
      });

  }

  /**
   * Si el usuario no selecciona guardar, cancelar los cambios
   */
  cancelFailureModeTypesChanges() {

    this.failureModeTypes.forEach(fmt => {

      fmt.status = true;
      fmt.checked = false;

    });
  }

  saveFailureModeTypes() {

    this.dataService.saveFailureModeTypes(this.failureModeTypes)
      .subscribe(data => {

        if (data.status) {
          this.failureModeTypes = data.failure_mode_types;

          UIkit.notification({
            message: 'Los tipos de modo de falla han sido guardados exitósamente',
            status: 'success',
            pos: 'top-center',
            timeout: 5000
          });

          UIkit.modal('#failure-mode-types-modal').hide();

        } else {

          UIkit.notification({
            message: data.message ? data.message : 'Ha ocurrido un error al guardar los tipos de modo de falla',
            status: 'danger',
            pos: 'top-center',
            timeout: 5000
          });

        }
      },
        data => {

          UIkit.notification({
            message: 'Ha ocurrido un error inesperado al guardar los tipos de modo de falla',
            status: 'danger',
            pos: 'top-center',
            timeout: 5000
          });

        });
  }

  openFailureModeTypesModal() {
    UIkit.modal('#failure-mode-types-modal').show();
  }

  openPartsModal() {
    UIkit.modal('#failure-mode-parts-modal').show();
    this.partsModalSeen = true;
  }

  savePartsSelection() {

    /*const selectedParts = [];
    this.availableParts.forEach(p => {
      if (p.checked) {
        selectedParts.push(p);
      }

    });

    this.failureMode.parts = selected;*/
    UIkit.modal('#failure-mode-parts-modal').hide();
  }

  /*removeFailureModePart(part) {


    UIkit.modal.confirm('Está seguro que desea eliminar este repuesto del modo de falla?')
      .then(() => {
        const i = this.failureMode.parts.indexOf(part);

        if (i !== -1) {
          this.failureMode.parts.splice(i, 1);
          part.checked = false;
          part.fmp_checked = false;
        }
      }, () => {
        console.log('Rejected.');
      });
  }*/

  removeFailureModePartRows() {


    UIkit.modal.confirm('Está seguro que desea eliminar estos repuestos del modo de falla?')
      .then(() => {


        const newSelected = [];
        this.selected.forEach(p => {

          let found = false;
          for (let i = 0; i < this.subsystemPartsSelected.length; i++) {
            if (this.subsystemPartsSelected[i].id === p.id) {
              found = true;
              break;
            }
          }

          if (!found) {
            newSelected.push(p);
          }
        });

        this.onSelect({ selected: newSelected });
        this.subsystemPartsSelected = [];

      }, () => {
        console.log('Rejected.');
      });
  }



  enabledFailureModesCount() {
    return this.failureModeTypes.filter(fmt => fmt.status).length;
  }

  checkAll(ev, tableType) {
    switch (tableType) {
      case 'failure-mode-types':

        if (this.failureModeTypes) {
          this.failureModeTypes.forEach(x => x.checked = ev.target.checked);
        }

        break;
      case 'failure-mode-parts':

        if (this.failureMode.parts) {
          this.failureMode.parts.forEach(x => x.fmp_checked = ev.target.checked);
        }

        break;
      case 'parts':

        if (this.availableParts) {
          this.availableParts.forEach(x => x.checked = ev.target.checked);
        }

        break;
    }
  }

  isAnyChecked(tableType) {

    switch (tableType) {
      case 'failure-mode-types':
        if (this.failureModeTypes) {
          return this.failureModeTypes.some(_ => _.checked);
        }
        break;
      case 'failure-mode-parts':
        if (this.failureMode.parts) {
          return this.failureMode.parts.some(_ => _.fmp_checked);
        }
        break;
      case 'parts':

        if (this.availableParts) {
          return this.availableParts.some(_ => _.checked);
        }
    }

    return false;
  }

  isAllChecked(tableType) {
    switch (tableType) {
      case 'failure-mode-types':

        if (this.failureModeTypes) {
          return this.failureModeTypes.every(_ => _.checked);
        }
        break;
      case 'failure-mode-parts':

        if (this.failureMode.parts) {
          return this.failureMode.parts.every(_ => _.fmp_checked);
        }
        break;
      case 'parts':

        if (this.availableParts) {
          return this.availableParts.every(_ => _.checked);
        }
    }

    return false;
  }

  setParts(parts) {

    this.availableParts = parts;

    // cache our list for future searches
    this.temp = [...parts];
  }

  onSelectSubsystemParts({ selected }) {
    this.subsystemPartsSelected.splice(0, this.subsystemPartsSelected.length);
    this.subsystemPartsSelected.push(...selected);
  }


  onSelect({ selected }) {
    this.selected.splice(0, this.selected.length);
    this.selected = [...selected];
  }

  /**
   * No fue posible realizar two-way binding con los checkbox de ngx-datatable
  removeFromSelection(element) {
    const index = this.selected.indexOf(element);
    if (index !== -1) {
      this.selected.splice(index, 1);
    }

    $('ngx-datatable .ngx-cgs-checkbox').first().trigger('change');
  }*/

  updateFilter(event) {
    const val = event.target.value.toLowerCase().trim();

    // filter our data
    const temp = this.temp.filter(d => {
      if (!val) { // return all rows if empty search
        return true;
      }

      for (const key of this.searchFields) { // Se busca match en cada campo filtrable

        switch (typeof d[key]) {
          case 'string':  // Para strings es case insensitive
            if (d[key] && d[key].toLowerCase().indexOf(val) !== -1) {
              return true;
            }
            break;
          case 'number':
            if (d[key] + '' === val) {
              return true;
            }
            break;
          default:

            if (d[key] === val) {
              return true;
            }

        }

      }

      return false;
    });

    // update the rows
    this.availableParts = temp;
    // Whenever the filter changes, always go back to the first page
    if (this.partsTable) {
      this.partsTable.offset = 0;
    }
  }
}
