import { ActivatedRoute, Router } from '@angular/router';
import { DataService } from './../../../shared/services/data.service';
import { Component, OnInit } from '@angular/core';

declare const $: any;
declare const UIkit: any;

@Component({
  selector: 'app-part',
  templateUrl: './part.component.html',
  styleUrls: ['./part.component.scss']
})

export class PartComponent implements OnInit {
  console = console;
  part: any = {
    id: null,
    original_code: null,
    code: null,
    name: '',
    erp_code: '',
    category_code: '',
    component_type_code: '',
    stock_quantity: null,
    description: '',
    part_number: '',
    cost: null,
    component_type: '',
    lead_time_buy: null,
    lead_time_storage: null,
    date_created: null,
    date_updated: null,
    observations: '',
    status: true,

    qualitative_analysis: {
      value: 1,
      mode: 'manual',
      data: null
    }
  };

  qualitativeAnalysisVariables = [];

  private paramSub: any;

  isLoaded = false;

  constructor(private router: Router, private route: ActivatedRoute, private dataService: DataService) { }

  ngOnInit() {

    this.paramSub = this.route.params.subscribe(params => {
      const partCode = params['code'];

      this.dataService.getQualitativeAnalysisVariables()
        .subscribe(data => {
          if (data.status) {

            this.qualitativeAnalysisVariables = data.qualitative_analysis_variables;

            if (partCode) {
              // Se muestra repuesto existente

              this.dataService.getPart(partCode)
                .subscribe(partData => {

                  if (partData.status) {

                    // Se normaliza la lista de analisis cualitativo
                    if (partData.part.qualitative_analysis) {
                      partData.part.qualitative_analysis.data = this.normalizeQualitativeAnalysis(partData.part.qualitative_analysis.data);
                    }

                    this.part = partData.part;

                    // Se recalcula el valor total
                    if (this.part.qualitative_analysis && this.part.qualitative_analysis.data) {
                      this.updateQualitativeAnalysisValue();
                    }

                    // Obtener modo de analysis
                    if (this.part.qualitative_analysis !== null) {
                      this.part.qualitative_analysis.mode = this.part.qualitative_analysis.data === null ? 'manual' : 'weight';
                    }
                  }

                  this.isLoaded = true;
                });
            } else {
              // Nuevo repuesto
              this.isLoaded = true;
            }

          }
        });


    });
  }

  savePart() {

    if (!$('#main-form').validationEngine('validate')) { return; }

    this.dataService.savePart(this.part)
      .subscribe(data => {

        if (data.status) {

          // Se normaliza la lista de analisis cualitativo
          if (data.part.qualitative_analysis) {
            data.part.qualitative_analysis.data = this.normalizeQualitativeAnalysis(data.part.qualitative_analysis.data);
          }

          this.part = data.part;

          // Obtener modo de analysis
          if (this.part.qualitative_analysis !== null) {
            this.part.qualitative_analysis.mode = this.part.qualitative_analysis.data === null ? 'manual' : 'weight';
          }

          UIkit.notification({
            message: 'El repuesto ha sido guardado exitósamente',
            status: 'success',
            pos: 'top-center',
            timeout: 5000
          });

        } else {
          UIkit.notification({
            message: data.message ? data.message : 'Ha ocurrido un error al guardar el repuesto',
            status: 'danger',
            pos: 'top-center',
            timeout: 5000
          });
        }
      },
        data => {

          UIkit.notification({
            message: 'Ha ocurrido un error inesperado al guardar el repuesto',
            status: 'danger',
            pos: 'top-center',
            timeout: 5000
          });
        });
  }

  deletePart() {
    UIkit.modal.confirm('Está seguro que desea eliminar este repuesto?', { stack: true })
      .then(() => {

        this.dataService.deletePart(this.part.original_code)
          .subscribe(data => {

            if (data.status) {
              UIkit.notification({
                message: 'El repuesto ha sido borrado',
                status: 'success',
                pos: 'top-center',
                timeout: 5000
              });

              this.router.navigate(['/sprisk/config/parts']);
            } else {

              UIkit.notification({
                message: 'Ha ocurrido un error al borrar el repuesto',
                status: 'danger',
                pos: 'top-center',
                timeout: 5000
              });
            }
          },
            data => {

              UIkit.notification({
                message: 'Ha ocurrido un error inesperado al borrar el repuesto',
                status: 'danger',
                pos: 'top-center',
                timeout: 5000
              });
            });
      });
  }

  openQualitativeAnalysis() {
    UIkit.modal('#qualitative-analysis-modal').show();
  }

  setQualitativeAnalysisEditionMode(mode) {

    if (mode === 'manual') {

      const parent = this;
      parent.part.qualitative_analysis.mode = 'weight';

      UIkit.modal.confirm('Esta acción cambiará la edición a modo manual, borrando cualquier ítem de análisis cualitativo ingresado. ' +
        'Está seguro que desea continuar?', { stack: true })
        .then(function () {
          parent.part.qualitative_analysis.data = null;
          parent.part.qualitative_analysis.mode = mode;
        }, function () {
          console.log('Rejected.');
        });


    } else {

      this.part.qualitative_analysis.data = this.normalizeQualitativeAnalysis([]);
      this.part.qualitative_analysis.mode = mode;
      this.updateQualitativeAnalysisValue();

    }
  }

  addQualitativeAnalysis() {
    // Analisis cualitativo aun no existe
    if (this.part.qualitative_analysis === null) {
      this.part.qualitative_analysis = {
        value: 1,
        data: [],
        mode: 'weight'
      };
    }

  }

  updateQualitativeAnalysisValue() {

    let qaValue = 0;

    this.part.qualitative_analysis.data.forEach(qa => {

      // Asegurar que valor no se escapa de los limites
      qa.value = Math.round(Math.max(qa.value, 1));
      qa.value = Math.min(qa.value, 5);

      if (qa.weight !== null && !isNaN(qa.weight) && qa.value !== null && !isNaN(qa.value)) {

        const weight = parseFloat(qa.weight) / 100;
        const value = parseFloat(qa.value);
        qaValue += weight * value;
      }
    });


    this.part.qualitative_analysis.value = Math.max(1, Math.round(qaValue * 100) / 100);
  }

  normalizeQualitativeAnalysis(qualitativeAnalysis) {

    if (qualitativeAnalysis === null) {
      return null;
    }

    const qualitativeAnalysisData = [];

    this.qualitativeAnalysisVariables.forEach(qav => {

      qav.value = 1; // Valor por defecto

      qualitativeAnalysis.forEach(qa => {
        if (qav.id == qa.type_id && !isNaN(qa.value)) {
          qav.value = qa.value;
        }

      });

      qualitativeAnalysisData.push(qav);

    });

    return qualitativeAnalysisData;
  }

}
