import { DataService } from './../../shared/services/data.service';
import { Component, OnInit, AfterViewInit } from '@angular/core';

declare const $: any;
declare const UIkit: any;

@Component({
  selector: 'app-config',
  templateUrl: './config.component.html',
  styleUrls: ['./config.component.scss']
})

export class ConfigComponent implements OnInit, AfterViewInit {
  moduleInfo: any = { 'title': 'SPRISK', 'key': 'sprisk' };
  constructor(private dataService: DataService) { }

  ngOnInit() {
  }

  ngAfterViewInit() {
  }

}
