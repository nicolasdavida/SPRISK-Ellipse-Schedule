import { DataService } from './../../../shared/services/data.service';
import { Router } from '@angular/router';
import { Component, OnInit, ViewChild } from '@angular/core';
import { DatatableComponent } from '@swimlane/ngx-datatable';

@Component({
  selector: 'app-failure-modes-list',
  templateUrl: './failure-modes-list.component.html',
  styleUrls: ['./failure-modes-list.component.scss']
})

export class FailureModesListComponent implements OnInit {

  failureModes = null;

  importExpectedColumns = [
    { id: 'name', name: 'Nombre', required: true },
    { id: 'fm_type', name: 'Tipo Modo de Falla', required: false }
  ];
  importUrl: string;

  // Variables de tabla
  @ViewChild(DatatableComponent) failureModesTable: DatatableComponent;
  selected = [];
  temp = [];
  searchFields = ['name', 'type_obj'];

  constructor(private router: Router, private dataService: DataService) { }

  ngOnInit() {

    this.dataService.getFailureModes().subscribe(data => {
      if (data.status) {

        this.setFailureModes(data.failure_modes);
      }
    });

    this.importUrl = this.dataService.getImportPath('failure_modes');
  }

  setFailureModes(failureModes) {

    this.failureModes = failureModes;

    // cache our list for future searches
    this.temp = [...failureModes];
  }

  addFailureMode() {
    this.router.navigate(['/sprisk/config/failure-mode', 0]);
  }

  editFailureMode(failureModeId) {
    this.router.navigate(['/sprisk/config/failure-mode', failureModeId]);
  }

  exportFailureModes() {

    const exportData = [['Nombre', 'Tipo', 'Repuestos']];

    this.temp.forEach(fm => {
      exportData.push([fm.name, fm.type_obj ? fm.type_obj.name : '-', fm.parts.length]);
    });

    this.dataService.exportExcel(exportData, 'Modos de Falla', 'Modos_Falla');
  }

  onImportResult(importResult) {

    if (importResult.status && importResult.failure_modes) {
      this.setFailureModes(importResult.failure_modes);
    }
  }

  /** Funciones relativas a la tabla */
  onSelect({ selected }) {
    this.selected.splice(0, this.selected.length);
    this.selected.push(...selected);
  }



  updateFilter(event) {
    const val = event.target.value.toLowerCase().trim();

    // filter our data
    const temp = this.temp.filter(d => {
      if (!val) { // return all rows if empty search
        return true;
      }

      for (const key of this.searchFields) { // Se busca match en cada campo filtrable

        switch (typeof d[key]) {
          case 'string':  // Para strings es case insensitive
            if (d[key] && d[key].toLowerCase().indexOf(val) !== -1) {
              return true;
            }
            break;
          case 'number':
            if (d[key] + '' === val) {
              return true;
            }
            break;
          default:

            if (key === 'type_obj' && d[key]
              && d[key].name.toLowerCase().indexOf(val) !== -1) { // Caso especifico para listado de modos de falla
              return true;
            }

            if (d[key] === val) {
              return true;
            }

        }

      }

      return false;
    });

    // update the rows
    this.failureModes = temp;
    // Whenever the filter changes, always go back to the first page
    if (this.failureModesTable) {
      this.failureModesTable.offset = 0;
    }
  }
}
