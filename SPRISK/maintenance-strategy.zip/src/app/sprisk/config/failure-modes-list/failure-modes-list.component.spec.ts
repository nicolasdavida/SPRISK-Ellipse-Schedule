import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FailureModesListComponent } from './failure-modes-list.component';

describe('FailureModesListComponent', () => {
  let component: FailureModesListComponent;
  let fixture: ComponentFixture<FailureModesListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FailureModesListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FailureModesListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
