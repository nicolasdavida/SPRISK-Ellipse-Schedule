import { Router, ActivatedRoute } from '@angular/router';
import { DataService } from './../../../shared/services/data.service';
import { Component, OnInit, AfterViewInit, OnDestroy } from '@angular/core';

declare const $: any;
declare const UIkit: any;

@Component({
  selector: 'app-catalog',
  templateUrl: './catalog.component.html',
  styleUrls: ['./catalog.component.scss']
})
export class CatalogComponent implements OnInit, AfterViewInit, OnDestroy {

  catalog: any = {
    id: null,
    original_code: '',
    code: '',
    name: '',
    description: '',
    graph_id: '',
    date_created: '',
    date_updated: '',
    status: true,

    subsystems: [],
    failure_modes: []
  };

  failureModes: any = [];

  treeContainerId = '#cgs-dlf';
  companyTreeData: any = [];
  companyTree: any = null;
  isLoaded = false;

  private paramSub: any;
  private catalogSub: any;
  private treeSub: any;
  private loadedCatalog: any = null;

  constructor(private router: Router, private route: ActivatedRoute, private dataService: DataService) {
    this.dataService.userCanEdit();
  }

  ngOnInit() {

    this.paramSub = this.route.params.subscribe(params => {
      const catalogCode = params['code'];

      this.dataService.getFailureModes().subscribe(data => {
        if (data.status) {
          this.failureModes = data.failure_modes;
        }
      });

      // Se obtienen los nodos
      this.treeSub = this.dataService.getCompanyTreeStructure();
      this.treeSub.subscribe(data => {

        const response = data;

        if (response['status'] == true) {
          this.companyTreeData = response['markers_list'];
        }
      });

      if (catalogCode && catalogCode !== '0') {

        this.catalogSub = this.dataService.getCatalog(catalogCode);
        this.catalogSub.subscribe(data => {
          if (data.status) {
            this.loadedCatalog = data.catalog;
          }
        });
      } else {
        this.isLoaded = true;
      }

    });



  }


  // TODO: mejorar secuencia de carga
  ngAfterViewInit() {

    this.treeSub.subscribe(data => {
      // Se dibuja el arbol dlf
      this.generateCompanyTree(this.companyTreeData, this.treeContainerId);

      // Si catalogSub existe, entonces se esta cargando un catalogo
      if (this.catalogSub) {

        // Esperar generacion de arbol
        setTimeout(() => {

          this.catalogSub.subscribe(() => {

            if (this.loadedCatalog.failure_modes) {
              // Normalizar a modelo angular
              this.loadedCatalog.failure_modes = this.normalizeFailureModes(this.loadedCatalog.failure_modes);
            }

            if (this.loadedCatalog.subsystems) {
              // Normalizar a modelo angular
              this.loadedCatalog.subsystems = this.normalizeSubsystems(this.loadedCatalog.subsystems);
            }

            this.catalog = this.loadedCatalog;
            this.isLoaded = true;
          });

        }, 1000);

      }
    });
  }


  ngOnDestroy() {
    /*if (this.paramSub) {
      this.paramSub.unsubscribe();
    }
    if (this.catalogSub) {
      this.catalogSub.unsubscribe();
    }
    if (this.treeSub) {
      this.treeSub.unsubscribe();
    }*/
  }

  saveCatalog() {

    if (!$('#main-form').validationEngine('validate')) { return; }

    this.dataService.saveCatalog(this.catalog).subscribe(data => {

      if (data.status) {

        if (data.catalog.failure_modes) {
          // Normalizar a modelo angular
          data.catalog.failure_modes = this.normalizeFailureModes(data.catalog.failure_modes);
        }

        if (data.catalog.subsystems) {
          // Normalizar a modelo angular
          data.catalog.subsystems = this.normalizeSubsystems(data.catalog.subsystems);
        }

        this.catalog = data.catalog;

        UIkit.notification({
          message: 'El catálogo ha sido guardado',
          status: 'success',
          pos: 'top-center',
          timeout: 5000
        });
      } else {
        UIkit.notification({
          message: 'Ha ocurrido un error al guardar el catálogo',
          status: 'danger',
          pos: 'top-center',
          timeout: 5000
        });
      }
    },
      data => {
        UIkit.notification({
          message: 'Ha ocurrido un error inesperado al guardar el catálogo',
          status: 'danger',
          pos: 'top-center',
          timeout: 5000
        });
      });

  }

  deleteCatalog() {

    UIkit.modal.confirm('Está seguro que desea borrar este catálogo?')
      .then(() => {

        this.dataService.deleteCatalog(this.catalog.original_code).subscribe(data => {
          if (data.status) {
            UIkit.notification({
              message: 'El catálogo ha sido borrado',
              status: 'success',
              pos: 'top-center',
              timeout: 5000
            });

            this.router.navigate(['/sprisk/config/catalogs']);
          } else {
            UIkit.notification({
              message: 'Ocurrió un error al borrar el catálogo',
              status: 'danger',
              pos: 'top-center',
              timeout: 5000
            });
          }
        },
          data => {
            UIkit.notification({
              message: 'Ha ocurrido un error inesperado al borrar el catálogo',
              status: 'danger',
              pos: 'top-center',
              timeout: 5000
            });
          });

      });
  }

  normalizeFailureModes(failureModes) {
    const catalogFailureModes = [];

    failureModes.forEach(fm => {

      for (let i = 0; i < this.failureModes.length; i++) {
        const failureMode = this.failureModes[i];

        if (fm.id == failureMode.id) {

          failureMode.checked = true;
          failureMode.cmf_checked = false;
          catalogFailureModes.push(failureMode);
        }
      }
    });

    return catalogFailureModes;
  }

  normalizeSubsystems(subsystems) {

    const normalizedSubsystems = [];
    this.companyTree.deselect_all();
    const treeNodes = this.companyTree.get_json('#', { flat: true });

    subsystems.forEach(ss => {
      for (let i = 0; i < treeNodes.length; i++) {

        if (ss.id_subsystem == treeNodes[i].data.subsystem_ref) {
          const subsystem = this.companyTree.get_node(treeNodes[i].id);

          if (subsystem) {
            this.companyTree.select_node(treeNodes[i].id);
            normalizedSubsystems.push(subsystem);
          }
          break;
        }
      }
    });

    return normalizedSubsystems;
  }

  openFailureModesModal() {

    UIkit.modal('#catalog-failure-modes-modal').show();

  }

  saveFailureModesSelection() {

    const selectedFailureModes = [];
    this.failureModes.forEach(fm => {
      if (fm.checked) {
        selectedFailureModes.push(fm);
      }

    });

    this.catalog.failure_modes = selectedFailureModes;
    UIkit.modal('#catalog-failure-modes-modal').hide();
  }


  removeFailureMode(fm) {

    UIkit.modal.confirm('Está seguro que desea eliminar este modo de falla?')
      .then(() => {
        const i = this.catalog.failure_modes.indexOf(fm);

        if (i !== -1) {
          this.catalog.failure_modes.splice(i, 1);
          fm.checked = false;
          fm.cfm_checked = false;
        }
      }, () => {
        console.log('Rejected.');
      });
  }

  removeFailureModeRows() {

    UIkit.modal.confirm('Está seguro que desea eliminar estos modos de falla?')
      .then(() => {

        this.catalog.failure_modes = this.catalog.failure_modes.filter(fm => {

          if (!fm.cfm_checked) {
            return true;
          }

          fm.checked = false;
          fm.cfm_checked = false;

          return false;
        });

      }, () => {
        console.log('Rejected.');
      });
  }

  /**
   * Si el usuario no selecciona guardar, cancelar los cambios
   */
  cancelFailureModeChanges() {

    this.failureModes.forEach(fm => {
      fm.checked = (this.catalog.failure_modes.indexOf(fm) !== -1);
    });
  }

  /**
   * Se genera el arbol DLF y se configuran sus eventos
   * @param tree arbol de nodos del DLF
   * @param selector selector DOM donde se dibujara el arbol
   */
  generateCompanyTree(tree, selector) {

    const IMG_URL = './assets/img';
    $(selector).jstree('destroy');
    $.jstree.defaults.checkbox.three_state = false;
    const parent = this;
    const treeTypes = {
      default: {
        icon: IMG_URL + '/jstree_icons/Search.png'
      },
      graph: {
        icon: IMG_URL + '/jstree_icons/corporation.png'
      },
      area: {
        icon: IMG_URL + '/jstree_icons/equipPlant.png'
      },
      linearmachine: {
        icon: IMG_URL + '/jstree_icons/line.png'
      },
      equipment: {
        icon: IMG_URL + '/jstree_icons/equip.png'
      },
      standbymachine: {
        icon: IMG_URL + '/jstree_icons/standby.png'
      },
      fractionmachine: {
        icon: IMG_URL + '/jstree_icons/fraction.png'
      },
      redundantmachine: {
        icon: IMG_URL + '/jstree_icons/redundant.png'
      },
      parallelmachine: {
        icon: IMG_URL + '/jstree_icons/parallel.png'
      },
      stockpile: {
        icon: IMG_URL + '/jstree_icons/stockpile.png'
      }
    };

    // Crear una instancia de js tree
    //noinspection TypeScriptUnresolvedFunction

    $(selector).jstree({
      'core': {
        data: tree,
        check_callback: true
      },
      types: treeTypes,
      state: { key: 'rmes-suite' },
      plugins: ['search', 'types', 'state', 'checkbox', 'contextmenu'],
      'contextmenu': {
        'items': function (node) {

          const t = $(selector).jstree(true);

          return {
            'view_details': {
              'separator_before': false,
              'separator_after': true,
              'label': 'Detalles',
              'action': function (obj) {
                const dialogHtml = `
                <div class="uk-padding">
                  <h3 class="uk-modal-title">${node.original.text}</h3>
                  <button class="uk-modal-close-full uk-close-large" type="button" uk-close></button>
                  <table class="uk-table uk-table-divider">
                    <tr><th>Nombre</th><td>${node.original.text}</td></tr>
                    <tr><th>Nickname</th><td>${node.data.nickname ? node.data.nickname : '<i>N/A</i>'}</td></tr>
                    <tr><th>Id</th><td>${node.data.subsystem_ref ? node.data.subsystem_ref : node.original.oid}</td></tr>
                  </table>
                </div>
                <div class="uk-modal-footer uk-text-right">
                  <button class="uk-button uk-button-primary uk-modal-close" type="button">Aceptar</button>
                </div>
                `;

                UIkit.modal.dialog(dialogHtml);

              }
            },
            'select_children': {
              'separator_before': false,
              'separator_after': false,
              'label': node.state.selected ? 'Deseleccionar hijos' : 'Seleccionar hijos',
              'action': function (obj) {

                if (node.state.selected) {
                  t.deselect_node(node.children, true); // No ejecuta eventos pues pueden ser muchos nodos
                  t.deselect_node(node.id);
                } else {
                  t.select_node(node.children, true); // No ejecuta eventos pues pueden ser muchos nodos
                  t.select_node(node.id);
                }

              }
            },
            'select_descendants': {
              'separator_before': false,
              'separator_after': true,
              'label': node.state.selected ? 'Deseleccionar todo' : 'Seleccionar todo',
              'action': function (obj) {

                if (node.state.selected) {
                  t.deselect_node(node.children_d, true); // No ejecuta eventos pues pueden ser muchos nodos
                  t.deselect_node(node.id);
                } else {
                  t.select_node(node.children_d, true); // No ejecuta eventos pues pueden ser muchos nodos
                  t.select_node(node.id);
                }

              }
            },
            'collapse_all': {
              'separator_before': false,
              'separator_after': false,
              'label': node.state.opened ? 'Colapsar todo' : 'Expandir todo',
              'action': function (obj) {

                const nodeChildren = node.children_d;
                if (node.state.opened) {
                  t.close_node(nodeChildren, null, nodeChildren.length < 100 ? true : false);
                  t.close_node(node, null, true);
                } else {
                  t.open_node(nodeChildren, null, nodeChildren.length < 100 ? true : false);
                  t.open_node(node, null, true);
                }

              }
            }
          };

        },
        'select_node': false
      }
    });

    parent.companyTree = $(selector).jstree(true);
    let to = null;
    $('#tree-search').keyup(function () {
      if (to) {
        clearTimeout(to);
      }
      to = setTimeout(function () {
        const v = $('#tree-search').val();
        if (v.length >= 3 || v.length === 0) {
          $(selector).jstree(true).search(v);
        }
      }, 250);
    });


    // Se asignan los eventos post carga del jstree para evitar multiples llamadas del plugin state
    $(selector).on('ready.jstree', function () {
      // Listener para click en elementos de jstree
      $(selector).on('changed.jstree', function (e, data) {
        const nodes = parent.companyTree.get_selected(true);
        parent.catalog.subsystems = nodes;

      });

      // Se ejecutan los eventos una vez para acualizar la app
      $(selector).trigger('changed.jstree');
    });

  }

  navigateTo(url) {

    UIkit.modal.confirm('Está por abandonar este catálogo. Cualquier cambio no guardado se perderá. Desea Continuar?', { stack: true })
      .then(() => {
        this.router.navigate([url]);
      }, () => {
        console.log('Rejected.');
      });
  }










  checkAll(ev, tableType) {
    switch (tableType) {
      case 'failure-modes':

        if (this.failureModes) {
          this.failureModes.forEach(x => x.checked = ev.target.checked);
        }

        break;
      case 'catalog-failure-modes':

        if (this.catalog.failure_modes) {
          this.catalog.failure_modes.forEach(x => x.cfm_checked = ev.target.checked);
        }

        break;
    }
  }

  isAnyChecked(tableType) {

    switch (tableType) {
      case 'failure-modes':
        if (this.failureModes) {
          return this.failureModes.some(_ => _.checked);
        }
        break;
      case 'catalog-failure-modes':
        if (this.catalog.failure_modes) {
          return this.catalog.failure_modes.some(_ => _.cfm_checked);
        }
        break;
    }

    return false;
  }

  isAllChecked(tableType) {
    switch (tableType) {
      case 'failure-modes':

        if (this.failureModes) {
          return this.failureModes.every(_ => _.checked);
        }
        break;
      case 'catalog-failure-modes':

        if (this.catalog.failure_modes) {
          return this.catalog.failure_modes.every(_ => _.cfm_checked);
        }
        break;
    }

    return false;
  }
}
