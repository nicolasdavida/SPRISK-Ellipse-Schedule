import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SubsystemsPartsComponent } from './subsystems-parts.component';

describe('SubsystemsPartsComponent', () => {
  let component: SubsystemsPartsComponent;
  let fixture: ComponentFixture<SubsystemsPartsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SubsystemsPartsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SubsystemsPartsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
