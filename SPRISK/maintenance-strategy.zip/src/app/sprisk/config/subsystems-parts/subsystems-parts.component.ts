import { DatatableComponent } from '@swimlane/ngx-datatable';

import { Router, ActivatedRoute } from '@angular/router';
import { DataService } from './../../../shared/services/data.service';
import { Component, OnInit, ViewChild } from '@angular/core';

declare const $: any;
declare const UIkit: any;
declare const numeral: any;

@Component({
  selector: 'app-subsystems-parts',
  templateUrl: './subsystems-parts.component.html',
  styleUrls: ['./subsystems-parts.component.scss']
})

export class SubsystemsPartsComponent implements OnInit {

  numeral = numeral;

  subsystems: any = null;
  parts: any = [];

  treeContainerId = '#cgs-dlf';
  companyTreeData: any = [];
  companyTree: any = null;
  isLoaded = false;

  isLoadingParts = false;

  private treeSub: any;


  importExpectedColumns = [
    { id: 'subsystem_id', name: 'Id Subsistema', required: true },
    { id: 'part_code', name: 'Cód. Repuesto', required: true }
  ];
  importUrl: string;

  // Variables de tabla de partes asignadas
  @ViewChild(DatatableComponent) subsystemPartsTable: DatatableComponent;
  subsystemPartsSelected = [];
  subsystemPartsTemp = [];

  // Variables de tabla Modal
  @ViewChild(DatatableComponent) partsTable: DatatableComponent;
  selected = [];
  temp = [];
  searchFields = ['name', 'code', 'erp_code', 'part_number'];

  partsModalSeen = false;
  qualitativeModalOpen = false;
  constructor(private router: Router, private route: ActivatedRoute, private dataService: DataService) {
    this.importUrl = this.dataService.getImportPath('subsystem_parts');
  }

  ngOnInit() {

    // Se obtiene listado de todas las partes
    this.dataService.getParts().subscribe(data => {

      if (data.status) {
        this.setParts(data.parts);
      }
    });

    // Se obtienen los nodos
    this.treeSub = this.dataService.getCompanyTreeStructure();
    this.treeSub.subscribe(data => {

      const response = data;

      if (response['status'] == true) {
        this.companyTreeData = response['markers_list'];
        this.generateCompanyTree(this.companyTreeData, this.treeContainerId);
      }

      this.isLoaded = true;
    });
  }

  saveSubsystemParts() {

    this.dataService.saveSubsystemPartsDirect(this.subsystems, this.selected).subscribe(data => {

      if (data.status) {

        UIkit.notification({
          message: 'La relación ha sido guardada',
          status: 'success',
          pos: 'top-center',
          timeout: 5000
        });

      } else {
        UIkit.notification({
          message: 'Ha ocurrido un error al guardar la relación',
          status: 'danger',
          pos: 'top-center',
          timeout: 5000
        });
      }
    },
      data => {
        UIkit.notification({
          message: 'Ha ocurrido un error inesperado al guardar la relación',
          status: 'danger',
          pos: 'top-center',
          timeout: 5000
        });
      });

  }

  openPartsModal() {

    UIkit.modal('#subsystem-parts-modal').show();
    this.partsModalSeen = true; // Evita problemas de renderizado

  }

  savePartsSelection() {

    /*console.log(this.selected);
    this.subsystem.parts = this.selected;*/
    UIkit.modal('#subsystem-parts-modal').hide();
  }

  /*removePart(part) {

    UIkit.modal.confirm('Está seguro que desea eliminar este repuesto?')
      .then(() => {
        const i = this.subsystems.parts.indexOf(part);

        if (i !== -1) {
          this.subsystems.parts.splice(i, 1);
          part.checked = false;
          part.ssp_checked = false;
        }
      }, () => {
        console.log('Rejected.');
      });
  }*/

  removePartsRows() {

    UIkit.modal.confirm('Está seguro que desea eliminar estos repuestos?')
      .then(() => {

        const newSelected = [];
        this.selected.forEach(p => {

          let found = false;
          for (let i = 0; i < this.subsystemPartsSelected.length; i++) {
            if (this.subsystemPartsSelected[i].id === p.id) {
              found = true;
              break;
            }
          }

          if (!found) {
            newSelected.push(p);
          }
        });


        this.onSelect({ selected: newSelected });
        this.subsystemPartsSelected = [];


      }, () => {
        console.log('Rejected.');
      });
  }

  /**
   * Se genera el arbol DLF y se configuran sus eventos
   * @param tree arbol de nodos del DLF
   * @param selector selector DOM donde se dibujara el arbol
   */
  generateCompanyTree(tree, selector) {

    const IMG_URL = './assets/img';
    $(selector).jstree('destroy');
    $.jstree.defaults.checkbox.three_state = false;
    const parent = this;
    const treeTypes = {
      default: {
        icon: IMG_URL + '/jstree_icons/equip.png'
      },
      graph: {
        icon: IMG_URL + '/jstree_icons/corporation.png'
      },
      area: {
        icon: IMG_URL + '/jstree_icons/equipPlant.png'
      },
      linearmachine: {
        icon: IMG_URL + '/jstree_icons/line.png'
      },
      equipment: {
        icon: IMG_URL + '/jstree_icons/equip.png'
      },
      standbymachine: {
        icon: IMG_URL + '/jstree_icons/standby.png'
      },
      fractionmachine: {
        icon: IMG_URL + '/jstree_icons/fraction.png'
      },
      redundantmachine: {
        icon: IMG_URL + '/jstree_icons/redundant.png'
      },
      parallelmachine: {
        icon: IMG_URL + '/jstree_icons/parallel.png'
      },
      stockpile: {
        icon: IMG_URL + '/jstree_icons/stockpile.png'
      }
    };

    // Crear una instancia de js tree
    //noinspection TypeScriptUnresolvedFunction

    $(selector).jstree({
      'core': {
        data: tree,
        check_callback: true
      },
      types: treeTypes,
      state: { key: 'rmes-suite' },
      plugins: ['search', 'types', 'state', 'checkbox', 'contextmenu'],
      'contextmenu': {
        'items': function (node) {

          const t = $(selector).jstree(true);

          return {
            'view_details': {
              'separator_before': false,
              'separator_after': true,
              'label': 'Detalles',
              'action': function (obj) {
                const dialogHtml = `
                <div class="uk-padding">
                  <h3 class="uk-modal-title">${node.original.text}</h3>
                  <button class="uk-modal-close-full uk-close-large" type="button" uk-close></button>
                  <table class="uk-table uk-table-divider">
                    <tr><th>Nombre</th><td>${node.original.text}</td></tr>
                    <tr><th>Nickname</th><td>${node.data.nickname ? node.data.nickname : '<i>N/A</i>'}</td></tr>
                    <tr><th>Id</th><td>${node.data.subsystem_ref ? node.data.subsystem_ref : node.original.oid}</td></tr>
                  </table>
                </div>
                <div class="uk-modal-footer uk-text-right">
                  <button class="uk-button uk-button-primary uk-modal-close" type="button">Aceptar</button>
                </div>
                `;

                UIkit.modal.dialog(dialogHtml);

              }
            },
            'select_children': {
              'separator_before': false,
              'separator_after': false,
              'label': node.state.selected ? 'Deseleccionar hijos' : 'Seleccionar hijos',
              'action': function (obj) {

                if (node.state.selected) {
                  t.deselect_node(node.children, true); // No ejecuta eventos pues pueden ser muchos nodos
                  t.deselect_node(node.id);
                } else {
                  t.select_node(node.children, true); // No ejecuta eventos pues pueden ser muchos nodos
                  t.select_node(node.id);
                }

              }
            },
            'select_descendants': {
              'separator_before': false,
              'separator_after': true,
              'label': node.state.selected ? 'Deseleccionar todo' : 'Seleccionar todo',
              'action': function (obj) {

                if (node.state.selected) {
                  t.deselect_node(node.children_d, true); // No ejecuta eventos pues pueden ser muchos nodos
                  t.deselect_node(node.id);
                } else {
                  t.select_node(node.children_d, true); // No ejecuta eventos pues pueden ser muchos nodos
                  t.select_node(node.id);
                }

              }
            },
            'collapse_all': {
              'separator_before': false,
              'separator_after': false,
              'label': node.state.opened ? 'Colapsar todo' : 'Expandir todo',
              'action': function (obj) {

                const nodeChildren = node.children_d;
                if (node.state.opened) {
                  t.close_node(nodeChildren, null, nodeChildren.length < 100 ? true : false);
                  t.close_node(node, null, true);
                } else {
                  t.open_node(nodeChildren, null, nodeChildren.length < 100 ? true : false);
                  t.open_node(node, null, true);
                }

              }
            }
          };

        },
        'select_node': false
      }
    });

    parent.companyTree = $(selector).jstree(true);
    let to = null;
    $('#tree-search').keyup(function () {
      if (to) {
        clearTimeout(to);
      }
      to = setTimeout(function () {
        const v = $('#tree-search').val();
        if (v.length >= 3 || v.length === 0) {
          $(selector).jstree(true).search(v);
        }
      }, 250);
    });


    // Se asignan los eventos post carga del jstree para evitar multiples llamadas del plugin state
    $(selector).on('ready.jstree', function () {


      // Listener para click en elementos de jstree
      $(selector).on('changed.jstree', function (e, data) {
        const nodes = parent.companyTree.get_selected(true);
        //parent.clearSelection();

        if (nodes.length > 0) {

          if (nodes.length === 1) {
            // Seleccion simple, cargar repuestos desde db

            const subsystem = nodes[0];
            parent.subsystems = [subsystem];
            parent.isLoadingParts = true;

            parent.dataService.getSubsystemPartsDirect(subsystem.data.subsystem_ref).subscribe(
              partsData => {

                if (partsData.status) {
                  parent.subsystemPartsSelected = [];
                  parent.selected = partsData.subsystem_parts;
                }
              },
              () => { },
              () => { parent.isLoadingParts = false; });

          } else {
            // Seleccion multiple, limpiar listado de repuestos y no cargar nada de db
            parent.subsystems = nodes;
            parent.subsystemPartsSelected = [];
            parent.selected = [];
          }
        } else {
          parent.subsystems = null;
          parent.subsystemPartsSelected = [];
          parent.selected = [];
        }

      });

      // Se ejecutan los eventos una vez para acualizar la app
      $(selector).trigger('changed.jstree');
    });

  }

  /*normalizeSubsystemParts(parts) {
    const partsData = [];

    parts.forEach(part => {
      for (let i = 0; i < this.parts.length; i++) {
        if (this.parts[i].code === part.code) {
          this.parts[i].ssp_checked = false;

          partsData.push(this.parts[i]);
        }
      }
    });

    return partsData;
  }*/

  navigateTo(url) {

    UIkit.modal.confirm('Está por abandonar esta página. Cualquier cambio no guardado se perderá. Desea Continuar?', { stack: true })
      .then(() => {
        this.router.navigate([url]);
      }, () => {
        console.log('Rejected.');
      });
  }

  setParts(parts) {

    this.parts = parts;

    // cache our list for future searches
    this.temp = [...parts];
  }




  /*clearSelection() {

    this.parts.forEach(x => {
      x.checked = false;
      x.ssp_checked = false;
    });
  }*/



  /*checkAll(ev, tableType) {
    switch (tableType) {
      case 'parts':

        if (this.parts) {
          this.parts.forEach(x => x.checked = ev.target.checked);
        }

        break;
      case 'subsystem-parts':

        if (this.subsystems.parts) {
          this.subsystems.parts.forEach(x => x.ssp_checked = ev.target.checked);
        }

        break;
    }
  }*/

  /*isAnyChecked(tableType) {

    switch (tableType) {
      case 'parts':
        if (this.parts) {
          return this.parts.some(_ => _.checked);
        }
        break;
      case 'subsystem-parts':
        if (this.subsystems.parts) {
          return this.subsystems.parts.some(_ => _.ssp_checked);
        }
        break;
    }

    return false;
  }

  isAllChecked(tableType) {
    switch (tableType) {
      case 'parts':

        if (this.parts) {
          return this.parts.every(_ => _.checked);
        }
        break;
      case 'subsystem-parts':

        if (this.subsystems.parts) {
          return this.subsystems.parts.every(_ => _.ssp_checked);
        }
        break;
    }

    return false;
  }*/

  onSelectSubsystemParts({ selected }) {
    this.subsystemPartsSelected.splice(0, this.subsystemPartsSelected.length);
    this.subsystemPartsSelected.push(...selected);
  }

  onSelect({ selected }) {
    this.selected.splice(0, this.selected.length);
    this.selected = [...selected];
  }

  /**
   * No fue posible realizar two-way binding con los checkbox de ngx-datatable
  removeFromSelection(element) {
    const index = this.selected.indexOf(element);
    if (index !== -1) {
      this.selected.splice(index, 1);
    }

    $('ngx-datatable .ngx-cgs-checkbox').first().trigger('change');
  }*/

  updateFilter(event) {
    const val = event.target.value.toLowerCase().trim();

    // filter our data
    const temp = this.temp.filter(d => {
      if (!val) { // return all rows if empty search
        return true;
      }

      for (const key of this.searchFields) { // Se busca match en cada campo filtrable

        switch (typeof d[key]) {
          case 'string':  // Para strings es case insensitive
            if (d[key] && d[key].toLowerCase().indexOf(val) !== -1) {
              return true;
            }
            break;
          case 'number':
            if (d[key] + '' === val) {
              return true;
            }
            break;
          default:

            if (d[key] === val) {
              return true;
            }

        }

      }

      return false;
    });

    // update the rows
    this.parts = temp;
    // Whenever the filter changes, always go back to the first page
    if (this.partsTable) {
      this.partsTable.offset = 0;
    }
  }
}
