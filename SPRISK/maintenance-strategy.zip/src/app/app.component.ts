import { AfterViewInit, ChangeDetectorRef, Component, OnDestroy, OnInit, ViewEncapsulation } from '@angular/core';
import { Router } from '@angular/router';
import { LoaderService } from './shared/services/loader.service';
import { DataService } from './shared/services/data.service';

declare var UIkit: any;

@Component({
    selector: 'app-root',
    templateUrl: './app.component.html',
    styleUrls: ['./app.component.scss'],
    encapsulation: ViewEncapsulation.None
})
export class AppComponent implements OnInit, AfterViewInit, OnDestroy {

    searchTerm = ''; // Usado para la busqueda de modulos

    isLoading = false;
    _subscription;

    constructor(private router: Router,
        public dataService: DataService,
        public loaderService: LoaderService,
        private cdRef: ChangeDetectorRef) {

    }

    ngOnInit() {
        // Si se recarga la pagina de la aplicacion, recuperar sesion

        // TODO: descomentar
        // const req = this.dataService.recoverSession();
        this.cdRef.detectChanges();
    }

    ngAfterViewInit() {
        this._subscription = this.loaderService.loadingChange.subscribe((value) => {
            this.isLoading = value;
        });
        this.cdRef.detectChanges();
    }

    ngOnDestroy() {
        // Se previenen fugas de memoria
        this._subscription.unsubscribe();
    }
}
