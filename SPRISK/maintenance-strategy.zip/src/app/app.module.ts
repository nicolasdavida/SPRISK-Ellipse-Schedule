import { AuthGuard } from './shared/services/auth-guard.service';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule, LOCALE_ID } from '@angular/core';

import { AppComponent } from './app.component';
import { FormsModule } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';
import { RiskMatrixComponent } from './risk-matrix/risk-matrix.component';
import { FmecaComponent } from './fmeca/fmeca.component';
import { MaintenancePlanComponent } from './maintenance-plan/maintenance-plan.component';
import { RcmComponent } from './rcm/rcm.component';
import { HttpModule } from '@angular/http';
import { HttpClientModule } from '@angular/common/http';

import { DecimalPipe } from '@angular/common';

import { SplitPaneModule } from 'ng2-split-pane/lib/ng2-split-pane';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';

import { DataService } from './shared/services/data.service';
import { GeneralInterceptorProvider } from './shared/services/general-interceptor';
import { LoaderService } from './shared/services/loader.service';
import { LoginComponent } from './login/login/login.component';
import { RmesSearchComponent } from './shared/components/rmes-search/rmes-search.component';
import { HomeComponent } from './home/home.component';
import { RmesModulesShowcaseComponent } from './home/components/rmes-modules-showcase/rmes-modules-showcase.component';
import { SpriskComponent } from './sprisk/sprisk.component';
import { ConfigComponent } from './sprisk/config/config.component';
import { PartComponent } from './sprisk/config/part/part.component';
import { PartsListComponent } from './sprisk/config/parts-list/parts-list.component';
import { FailureModeComponent } from './sprisk/config/failure-mode/failure-mode.component';
import { FailureModesListComponent } from './sprisk/config/failure-modes-list/failure-modes-list.component';
import { CatalogsComponent } from './sprisk/config/catalogs/catalogs.component';
import { CatalogComponent } from './sprisk/config/catalog/catalog.component';
import { QualitativeAnalysisComponent } from './sprisk/config/qualitative-analysis/qualitative-analysis.component';
import { SubsystemsPartsComponent } from './sprisk/config/subsystems-parts/subsystems-parts.component';
import { CsvMapperComponent } from './shared/components/csv-mapper/csv-mapper.component';


const appRoutes: Routes = [
    { path: 'login', component: LoginComponent },
    // { path: 'risk-matrix', component: RiskMatrixComponent },
    // { path: 'fmeca', component: FmecaComponent },
    // { path: 'rcm', component: RcmComponent },
    // { path: 'maintenance-plan', component: MaintenancePlanComponent },
    { path: 'sprisk', component: SpriskComponent },
    { path: 'sprisk/config', component: ConfigComponent, canActivate: [AuthGuard]},
    { path: 'sprisk/config/parts', component: PartsListComponent, canActivate: [AuthGuard] },
    { path: 'sprisk/config/part', component: PartComponent, canActivate: [AuthGuard] },
    { path: 'sprisk/config/part/:code', component: PartComponent, canActivate: [AuthGuard] },
    { path: 'sprisk/config/failure-modes', component: FailureModesListComponent, canActivate: [AuthGuard] },
    { path: 'sprisk/config/failure-mode/:id', component: FailureModeComponent, canActivate: [AuthGuard] },
    { path: 'sprisk/config/catalogs', component: CatalogsComponent, canActivate: [AuthGuard] },
    { path: 'sprisk/config/catalog/:code', component: CatalogComponent, canActivate: [AuthGuard] },
    { path: 'sprisk/config/qualitative-analysis', component: QualitativeAnalysisComponent, canActivate: [AuthGuard] },
    { path: 'sprisk/config/subsystem-parts', component: SubsystemsPartsComponent, canActivate: [AuthGuard] },
    // { path: 'sprisk/test', component: CsvMapperComponent },
    { path: '**', component: SpriskComponent }
];


@NgModule({
    declarations: [
        AppComponent,
        RiskMatrixComponent,
        FmecaComponent,
        RcmComponent,
        MaintenancePlanComponent,
        LoginComponent,
        RmesSearchComponent,
        HomeComponent,
        RmesModulesShowcaseComponent,
        SpriskComponent,
        ConfigComponent,
        PartComponent,
        FailureModeComponent,
        CatalogsComponent,
        FailureModesListComponent,
        PartsListComponent,
        CatalogComponent,
        QualitativeAnalysisComponent,
        SubsystemsPartsComponent,
        CsvMapperComponent

    ],
    imports: [
        RouterModule.forRoot(
            appRoutes, { useHash: true }
            // {enableTracing: true}  <-- debugging purposes only
        ),
        HttpModule,
        HttpClientModule,
        BrowserModule,
        FormsModule,

        // Externals
        SplitPaneModule,
        NgxDatatableModule
    ],
    providers: [
        AuthGuard,
        { provide: LOCALE_ID, useValue: 'es-CL' }, // Cambiar segun sea necesario
        DataService,
        GeneralInterceptorProvider,
        LoaderService,
        DecimalPipe],
    bootstrap: [AppComponent]
})

export class AppModule {
    // constructor(private dataService: DataService) {
    //
    // }
}
