'use strict';

export const Globals = Object.freeze({
    COMPANY_NAME: 'CGS S.A.',
    COMPANY_CONTACT: 'Alessio Arata <alessio.arata@cgssa.com>',

    APP_VERSION: '1.0',
    APP_LOCAL_STORAGE_KEY: 'cgs_rmes',
    // APP_LOCALE: { locale: 'en-US', fallback: 'en-EN' },
    APP_LOCALE: { locale: 'es-CL', fallback: 'es-ES' },

    API_BASE_URL: 'http://sprisk.rmessuite.com/backend/' // Testing @ suitedev.cgssa.com
    // API_BASE_URL: 'http://localhost/rmes/suite-backend/' // Localhost
});
