import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RmesSearchComponent } from './rmes-search.component';

describe('RmesSearchComponent', () => {
  let component: RmesSearchComponent;
  let fixture: ComponentFixture<RmesSearchComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RmesSearchComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RmesSearchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
