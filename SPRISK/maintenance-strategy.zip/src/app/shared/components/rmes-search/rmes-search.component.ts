import {
    Component,
    Input,
    OnInit
} from '@angular/core';
import {
    Router
} from '@angular/router';
import {
    RmesModule
} from '../../classes/rmes-module';
import { DataService } from './../../services/data.service';

@Component({
    selector: 'app-rmes-search',
    templateUrl: './rmes-search.component.html',
    styleUrls: ['./rmes-search.component.scss']
})

export class RmesSearchComponent implements OnInit {
    @Input() context: string;
    _searchTerm = '';

    relatedModules = 'risk-matrix,fmeca,rcm,maintenance-plan';
    rmesModules: RmesModule[] = [];
    modulesFilterTerm = '';
    isLoading = false;

    @Input()
    set searchTerm(searchTerm) {
        this._searchTerm = searchTerm.trim().toLowerCase();
        for (let i = 0; i < this.rmesModules.length; i++) {
            const module = this.rmesModules[i];

            module.filtered_out = module.enabled === false ||
                (this._searchTerm !== '' && module.keywords.toLowerCase().indexOf(this._searchTerm) === -1);

        }
    }

    constructor(private router: Router, private dataService: DataService) {
        this.rmesModules = [];
    }

    ngOnInit() {
        this.rmesModules = this.dataService.getRmesModules();
    }

    navigateToModule(module) {

        if (module.url !== '#') {
            this.router.navigateByUrl('/' + module.url);
        }
    }


}
