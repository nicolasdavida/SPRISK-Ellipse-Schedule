import { DataService } from './../../services/data.service';
import { PartsListComponent } from './../../../sprisk/config/parts-list/parts-list.component';
import { Component, Input, Output, EventEmitter, OnInit } from '@angular/core';

declare const $: any;
declare const UIkit: any;

@Component({
  selector: 'app-rmes-csv-mapper',
  templateUrl: './csv-mapper.component.html',
  styleUrls: ['./csv-mapper.component.scss']
})

export class CsvMapperComponent implements OnInit {

  columns = [];
  data = [];
  @Input() expectedColumns: any[];
  @Input() importUrl: string;
  @Input() recordName = 'Registros';

  @Output() imported: EventEmitter<any> = new EventEmitter<any>();

  previewLimit = 5;
  uploadStatus = -1;
  uploadResponse = null;

  constructor(private dataService: DataService) {
  }

  ngOnInit() {
    // Wait for dom
    setTimeout(() => {
      this.setupUploadControls();
    }, 1000);

  }

  doRemap() {
    const unassignedFields = this.getUnassignedFields(false);

    if (unassignedFields.length === 0) {

      this.remapAndSave();

    } else {

      UIkit.modal.confirm(`Aún hay ${unassignedFields.length} campos sin asignar.<br><br>
      <b>Campos: ${unassignedFields.join(', ')}</b>
      <br><br>
      Desea continuar?`, { stack: true })
        .then(() => {
          this.remapAndSave();
        });
    }

  }

  /**
   * Se obtiene el objeto final con los campos asignados y se envian para ser importados
   */
  remapAndSave() {
    const recordsLabel = this.recordName.toLowerCase();

    // Por cada fila de datos
    const importData = this.data.map(e => {

      // Se retorna una nueva fila solo con los datos remappeados
      const newRow = {};
      this.expectedColumns.forEach(element => {
        if (element.mapped !== null) {
          newRow[element.id] = e[element.mapped];
        }
      });

      return newRow;

    });

    // Se envian los datos remappeados al backend
    this.dataService.importData(this.importUrl, importData)
      .subscribe(
        data => {

          if (data.status) {

            UIkit.notification({
              message: 'Se han importado ' + data.inserted_count + ' ' + recordsLabel + ' exitósamente',
              status: 'success',
              pos: 'top-center',
              timeout: 5000
            });
            UIkit.modal('#csv-assign-modal').hide();

          } else {

            UIkit.notification({
              message: 'Ocurrió un error al importar los ' + recordsLabel,
              status: 'danger',
              pos: 'top-center',
              timeout: 5000
            });
          }

          // Se emite el evento con la data para los componentes padres
          this.imported.emit(data);

        },
        () => {

          UIkit.notification({
            message: 'Ocurrió un error inesperado al importar los ' + recordsLabel,
            status: 'danger',
            pos: 'top-center',
            timeout: 5000
          });

        });
  }

  /**
   * El campo esperado es mapeado a la columna correspondiente
   * @param column columna del input
   * @param field campo del listado de campo esperado
   */
  mapColumn(column, field) {

    column = column.toLowerCase();

    // Se resetea cualquier columna ya mapeada al valor a asignar
    for (let i = 0; i < this.expectedColumns.length; i++) {

      if (this.expectedColumns[i].mapped === column) {
        this.expectedColumns[i].mapped = null;
      }

    }

    if (field === null) {
      return;
    }

    for (let i = 0; i < this.expectedColumns.length; i++) {

      if (this.expectedColumns[i].id === field) {
        this.expectedColumns[i].mapped = column ? column : null;
      }

    }

  }

  /**
   * Se intenta adivinar correspondencias entre los campos del csv y los campos esperados
   */
  findFieldsMatch() {
    this.columns = this.getFields(this.data);

    // Se busca el match por codigo
    this.columns.forEach(column => {

      this.expectedColumns.forEach(e => {

        const field = column.toLowerCase();

        // Se encontro match entre campo esperado y columna
        if (field === e.id && e.mapped === null) {
          e.mapped = field;
        }

      });
    });

  }

  /**
   * @param data arreglo de objetos json
   */
  getFields(data) {

    if (data && data.length > 0 && data[0]) {

      return Object.keys(data[0]);

    }

    return null;
  }

  /**
   * Se obtiene una lista de nombres de los campos (obligatorios?) faltantes
   * @param requiredOnly devuelve solo los campos obligatorios
   */
  getUnassignedFields(requiredOnly) {

    if (requiredOnly) {
      return this.expectedColumns.filter(c => c.required && c.mapped === null).map(c => c.name);
    }

    return this.expectedColumns.filter(c => c.mapped === null).map(c => c.name);
  }

  /**
   * Setup de campo UIkit para upload
   */
  setupUploadControls() {
    const that = this;
    const appLocale = this.dataService.getAppLocale();

    UIkit.upload('.js-upload', {

      url: this.dataService.backendUrl + 'sprisk_api/parse_csv',
      name: 'content',
      multiple: false,
      allow: '*.csv',

      beforeSend: function () {
        that.uploadStatus = 0;
      },
      complete: function () {
        const res = JSON.parse(arguments[0].response);

        if (res.status) {
          that.uploadStatus = 1;
          that.uploadResponse = res;
          that.data = res.csv;

          // Inicializar campo mapping
          that.expectedColumns.forEach(e => {
            e.mapped = null;
          });

          that.findFieldsMatch();

          UIkit.modal('#csv-assign-modal').show();

        } else {
          that.uploadStatus = -1;

          UIkit.notification({
            message: 'Ocurrió un error al cargar el archivo',
            status: 'danger',
            pos: 'top-center',
            timeout: 5000
          });
        }
      }

    });
  }
}
