export class RmesModule {

    id: number;
    key: string;
    url: string;
    name: string;
    short_name: string;
    icon_url: string;
    keywords: string;
    enabled: boolean;
    filtered_out: boolean;

    children: RmesModule[];

    constructor() {
        this.filtered_out = false;
        this.children = [];
    }
}
