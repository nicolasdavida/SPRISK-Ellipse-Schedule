import { Injectable, LOCALE_ID } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { Globals } from '../../app.globals';
import { UserPreferences } from '../classes/user-preferences';
import { User } from '../classes/user';
import { Router } from '@angular/router';
import { RmesModule } from '../classes/rmes-module';
import { toBase64String } from '@angular/compiler/src/output/source_map';

import * as XLSX from 'xlsx';
import { saveAs } from 'file-saver';

declare var $: any;

@Injectable()
export class DataService {

    appLocale;
    backendUrl: string;
    userPreferences: UserPreferences;
    user: User = null;


    importPaths = {
        'parts': 'sprisk_api/data_import/parts',
        'failure_modes': 'sprisk_api/data_import/failure-modes',
        'catalogs': 'sprisk_api/data_import/catalogs',
        'subsystem_parts': 'sprisk_api/data_import/subsystem-parts'
    };

    rmesModulesDefinition = [
        { id: 0, key: 'apmc', parent: '', type: 'group', url: 'apm-cycle', name: 'APM Cycle', short_name: 'APM Cycle', icon_url: './assets/img/icons/pie-chart.png', keywords: 'apm,cycle', enabled: true, filtered_out: false },
        { id: 0, key: 'df', parent: 'apmc', type: 'module', url: 'data-fill', name: 'Data Fill', short_name: 'Data Fill', icon_url: './assets/img/icons/pie-chart.png', keywords: 'data,fill', enabled: true, filtered_out: false },
        { id: 0, key: 'cr', parent: 'apmc', type: 'module', url: 'custom-reports', name: 'Custom Reports', short_name: 'Custom Rep.', icon_url: './assets/img/icons/pie-chart.png', keywords: 'custom,reports', enabled: true, filtered_out: false },
        { id: 0, key: 'rca', parent: 'apmc', type: 'module', url: 'rca', name: 'RCA', short_name: 'RCA', icon_url: './assets/img/icons/pie-chart.png', keywords: 'rca', enabled: true, filtered_out: false },
        { id: 0, key: 'dsb', parent: 'apmc', type: 'module', url: 'dashboard', name: 'Dashboard', short_name: 'Dashboard', icon_url: './assets/img/icons/pie-chart.png', keywords: 'dashboard', enabled: true, filtered_out: false },

        { id: 0, key: 'rb', parent: '', type: 'group', url: 'rmes-basics', name: 'RMES Basics', short_name: 'Basics', icon_url: './assets/img/icons/pie-chart.png', keywords: 'rmes,basics', enabled: true, filtered_out: false },
        { id: 0, key: 'ta', parent: 'rb', type: 'module', url: 'total-assets', name: 'Total Assets', short_name: 'Total Assets', icon_url: './assets/img/icons/pie-chart.png', keywords: 'total,assets', enabled: true, filtered_out: false },
        { id: 0, key: 'rama', parent: 'rb', type: 'module', url: 'ram-analysis', name: 'RAM Analysis', short_name: 'RAM Analysis', icon_url: './assets/img/icons/pie-chart.png', keywords: 'ram,analysis', enabled: true, filtered_out: false },
        { id: 0, key: 'cls', parent: 'rb', type: 'module', url: 'cluster', name: 'Cluster', short_name: 'Cluster', icon_url: './assets/img/icons/pie-chart.png', keywords: 'cluster', enabled: true, filtered_out: false },
        { id: 0, key: 'oee', parent: 'rb', type: 'module', url: 'oee', name: 'OEE', short_name: 'OEE', icon_url: './assets/img/icons/pie-chart.png', keywords: 'oee', enabled: true, filtered_out: false },

        { id: 0, key: 'apma', parent: '', type: 'group', url: 'apm-analytics', name: 'APM Analytics', short_name: 'APM Analytics', icon_url: './assets/img/icons/pie-chart.png', keywords: 'apm,analytics', enabled: true, filtered_out: false },
        { id: 0, key: 'ins', parent: 'apma', type: 'module', url: 'insights', name: 'Insights', short_name: 'Insights', icon_url: './assets/img/icons/pie-chart.png', keywords: 'insights', enabled: true, filtered_out: false },
        { id: 0, key: 'pm', parent: 'apma', type: 'module', url: 'predictive-maintenance', name: 'Predictive Maintenance', short_name: 'Predic. Maint.', icon_url: './assets/img/icons/pie-chart.png', keywords: 'predictive,maintenance', enabled: true, filtered_out: false },
        { id: 0, key: 'sprisk', parent: 'apma', type: 'module', url: 'sprisk', name: 'SPRISK', short_name: 'SPRISK', icon_url: './assets/img/icons/pie-chart.png', keywords: 'sprisk,parts,partes,repuestos', enabled: true, filtered_out: false },
        { id: 0, key: 'cont', parent: 'apma', type: 'module', url: 'contractors', name: 'Contractors', short_name: 'Contractors', icon_url: './assets/img/icons/pie-chart.png', keywords: 'contractors', enabled: true, filtered_out: false },

        { id: 0, key: 'rams', parent: '', type: 'group', url: 'ram-simulation', name: 'RAM Simulation', short_name: 'RAM Sim.', icon_url: './assets/img/icons/pie-chart.png', keywords: 'ram,simulation', enabled: true, filtered_out: false },
        { id: 0, key: 'pf', parent: 'rams', type: 'module', url: 'plan-forecast', name: 'Plan Forecast', short_name: 'Plan Forecast', icon_url: './assets/img/icons/pie-chart.png', keywords: 'plan,forecast', enabled: true, filtered_out: false },
        { id: 0, key: 'psim', parent: 'rams', type: 'module', url: 'plan-sim', name: 'Plan Sim', short_name: 'Plan Sim', icon_url: './assets/img/icons/pie-chart.png', keywords: 'plan,sim', enabled: true, filtered_out: false },
        { id: 0, key: 'lcc', parent: 'rams', type: 'module', url: 'lcc', name: 'LCC', short_name: 'LCC', icon_url: './assets/img/icons/pie-chart.png', keywords: 'lcc', enabled: true, filtered_out: false },
        { id: 0, key: 'pos', parent: 'rams', type: 'module', url: 'pos', name: 'POS', short_name: 'POS', icon_url: './assets/img/icons/pie-chart.png', keywords: 'pos', enabled: true, filtered_out: false },

        { id: 0, key: 'ms', parent: '', type: 'group', url: 'maintenance-strategy', name: 'Maintenance Strategy', short_name: 'Maint. Strategy', icon_url: './assets/img/icons/pie-chart.png', keywords: 'maintenance,strategy', enabled: true, filtered_out: false },
        { id: 0, key: 'rm', parent: 'ms', type: 'module', url: 'risk-matrix', name: 'Risk Matrix', short_name: 'Risk Matrix', icon_url: './assets/img/icons/pie-chart.png', keywords: 'risk,matrix', enabled: true, filtered_out: false },
        { id: 0, key: 'rf', parent: 'ms', type: 'module', url: 'rcm-&-fmeca', name: 'RCM & FMECA', short_name: 'RCM & FMECA', icon_url: './assets/img/icons/pie-chart.png', keywords: 'rcm,&,fmeca', enabled: true, filtered_out: false },
        { id: 0, key: 'rbi', parent: 'ms', type: 'module', url: 'rbi', name: 'RBI', short_name: 'RBI', icon_url: './assets/img/icons/pie-chart.png', keywords: 'rbi', enabled: true, filtered_out: false },
        { id: 0, key: 'mp', parent: 'ms', type: 'module', url: 'maintenance-plan', name: 'Maintenance Plan', short_name: 'Maint. Plan', icon_url: './assets/img/icons/pie-chart.png', keywords: 'maintenance,plan', enabled: true, filtered_out: false },

        { id: 0, key: 'ra', parent: '', type: 'group', url: 'risk-assessment', name: 'Risk Assessment', short_name: 'Risk Assess.', icon_url: './assets/img/icons/pie-chart.png', keywords: 'risk,assessment', enabled: true, filtered_out: false },
        { id: 0, key: 'hazop', parent: 'ra', type: 'module', url: 'hazop', name: 'HAZOP', short_name: 'HAZOP', icon_url: './assets/img/icons/pie-chart.png', keywords: 'hazop', enabled: true, filtered_out: false },
        { id: 0, key: 'hazid', parent: 'ra', type: 'module', url: 'hazid', name: 'HAZID', short_name: 'HAZID', icon_url: './assets/img/icons/pie-chart.png', keywords: 'hazid', enabled: true, filtered_out: false },
        { id: 0, key: 'fta', parent: 'ra', type: 'module', url: 'fta', name: 'FTA', short_name: 'FTA', icon_url: './assets/img/icons/pie-chart.png', keywords: 'fta', enabled: true, filtered_out: false },
        { id: 0, key: 'markov', parent: 'ra', type: 'module', url: 'markov', name: 'Markov', short_name: 'Markov', icon_url: './assets/img/icons/pie-chart.png', keywords: 'markov', enabled: true, filtered_out: false },

        { id: 0, key: 'bp', parent: '', type: 'group', url: 'business-performance', name: 'Business Performance', short_name: 'Business Perf.', icon_url: './assets/img/icons/pie-chart.png', keywords: 'business,performance', enabled: true, filtered_out: false },
        { id: 0, key: 'obs', parent: 'bp', type: 'module', url: 'observatory', name: 'Observatory', short_name: 'Observatory', icon_url: './assets/img/icons/pie-chart.png', keywords: 'observatory', enabled: true, filtered_out: false },
        { id: 0, key: 'bv', parent: 'bp', type: 'module', url: 'business-view', name: 'Business View', short_name: 'Business View', icon_url: './assets/img/icons/pie-chart.png', keywords: 'business,view', enabled: true, filtered_out: false },
        { id: 0, key: 'docs', parent: 'bp', type: 'module', url: 'docs', name: 'Docs', short_name: 'Docs', icon_url: './assets/img/icons/pie-chart.png', keywords: 'docs', enabled: true, filtered_out: false },
        { id: 0, key: 'conn', parent: 'bp', type: 'module', url: 'connect', name: 'Connect', short_name: 'Connect', icon_url: './assets/img/icons/pie-chart.png', keywords: 'connect', enabled: true, filtered_out: false },

        { id: 0, key: 'ss', parent: '', type: 'group', url: 'system-setup', name: 'System Setup', short_name: 'System Setup', icon_url: './assets/img/icons/pie-chart.png', keywords: 'system,setup', enabled: true, filtered_out: false },
        { id: 0, key: 'rbdm', parent: 'ss', type: 'module', url: 'rbd-manager', name: 'RBD Manager', short_name: 'RBD Manager', icon_url: './assets/img/icons/pie-chart.png', keywords: 'rbd,manager', enabled: true, filtered_out: false },
        { id: 0, key: 'set', parent: 'ss', type: 'module', url: 'settings', name: 'Settings', short_name: 'Settings', icon_url: './assets/img/icons/pie-chart.png', keywords: 'settings', enabled: true, filtered_out: false },
        { id: 0, key: 'cat', parent: 'ss', type: 'module', url: 'catalogs', name: 'Catalogs', short_name: 'Catalogs', icon_url: './assets/img/icons/pie-chart.png', keywords: 'catalogs', enabled: true, filtered_out: false },
        { id: 0, key: 'sup', parent: 'ss', type: 'module', url: 'support', name: 'Support', short_name: 'Support', icon_url: './assets/img/icons/pie-chart.png', keywords: 'support', enabled: true, filtered_out: false }

    ];
    rmesModules: RmesModule[] = [];

    constructor(private router: Router, private http: HttpClient) {
        this.backendUrl = Globals.API_BASE_URL;
        this.appLocale = Globals.APP_LOCALE;
    }


    getRmesModules() {

        if (this.rmesModules.length === 0) {
            const modules = this.rmesModulesDefinition.filter(e => {
                return e.enabled === true; // Se eliminan los modulos no habilitados
            }).map(e => {
                const rmodule = new RmesModule();
                return Object.assign(rmodule, e);
            });

            this.rmesModules = modules;
        }

        return this.rmesModules;
    }

    /*
    Usado en Risk Matrix
     */
    saveRiskMatrix(riskDimensions: any): Observable<any> {
        const url = this.backendUrl + 'api/save_changes';
        const body = { 'risk_dimensions': riskDimensions };

        const req = this.http.post(url, body);

        return req;
    }

    /*
    Usado en Risk Matrix
     */
    getRiskMatrixDimensions(): Observable<any> {
        const url = this.backendUrl + 'api/risk_matrix_dimensions';
        const req = this.http.get(url);

        return req;
    }


    getCompanyTreeStructure() {
        const url = this.backendUrl + 'sprisk_api/company_structure';
        const req = this.http.get(url);

        return req;
    }

    getRiskMatrixOptions() {
        const url = this.backendUrl + 'api/fmeca_risk_matrix_options';
        const req = this.http.get(url);

        return req;
    }

    getSubsystemParts(subsystemId) {

        const url = this.backendUrl + 'api/parts?subsystem_id=' + subsystemId;
        const req = this.http.get(url);

        return req;
    }
    getSubsystemsParts(subsystemsIds) {

        const url = this.backendUrl + 'api/parts?subsystem_id=' + subsystemsIds.join(',');
        const req = this.http.get(url);

        return req;
    }

    saveFmecaRcm(changedNodes) {

        const url = this.backendUrl + 'api/save_fmeca_rcm_changes';

        const body = { 'fmeca_rcm_matrix': changedNodes };
        const req = this.http.post(url, body);

        return req;
    }

    /**
     * Se cargan las preferencias de usuario y se almacenan para ser usadas posteriormente
     */
    loadUserPreferences() {
        this.userPreferences = new UserPreferences();
        const up = localStorage.getItem(Globals.APP_LOCAL_STORAGE_KEY);

        if (up) {
            this.userPreferences = Object.assign(this.userPreferences, JSON.parse(up));
        }
    }

    getUserPreferences() {

        if (!this.userPreferences) {
            this.loadUserPreferences();
        }

        return this.userPreferences;

    }

    saveUserPreferences(preference) {
        const appLocalStorageKey = Globals.APP_LOCAL_STORAGE_KEY;
        const rmesLocalStorage = localStorage.getItem(appLocalStorageKey);

        let userPreferences = new UserPreferences();

        if (rmesLocalStorage) {
            const newPreference = $.extend(true, JSON.parse(rmesLocalStorage), preference);
            userPreferences = Object.assign(userPreferences, newPreference);
        } else {
            userPreferences = Object.assign(userPreferences, preference);
        }

        this.userPreferences = userPreferences;
        localStorage.setItem(appLocalStorageKey, JSON.stringify(userPreferences));
    }

    getDecisionTreeStructure(): Observable<any> {
        const url = this.backendUrl + 'api/decision_tree_structure';
        const req = this.http.get(url);

        return req;
    }

    saveDecisionTreeStructure(structure): Observable<any> {

        const url = this.backendUrl + 'api/save_decision_tree_structure';
        const body = { 'structure': structure };

        const req = this.http.post(url, body);

        return req;
    }

    /**
     * SPrisk
     */
    calculateRisks(SubsystemsIds, reportConfigs): Observable<any> {

        const url = this.backendUrl + 'sprisk_api/calculate_risks';

        const body = {
            'selected_assets': SubsystemsIds,
            'date_from': reportConfigs.date_from,
            'date_to': reportConfigs.date_to,
            'horizon': reportConfigs.horizon,
            'period_type': reportConfigs.period.selected,
            'dependence_type': reportConfigs.mode.selected,
            'dependence_value': reportConfigs.mode.value, // Solo usado para pow
            'risk_reduction': reportConfigs.risk_reduction.enabled ? reportConfigs.risk_reduction.value : null
        };

        const req = this.http.post(url, body);

        return req;
    }

    /**
     * SPrisk
     */
    calculateRisksByParts(partsIds, reportConfigs): Observable<any> {

        const url = this.backendUrl + 'sprisk_api/calculate_risks_by_parts';

        const body = {
            'selected_parts': partsIds,
            'date_from': reportConfigs.date_from,
            'date_to': reportConfigs.date_to,
            'horizon': reportConfigs.horizon,
            'period_type': reportConfigs.period.selected,
            'dependence_type': reportConfigs.mode.selected,
            'dependence_value': reportConfigs.mode.value, // Solo usado para pow
            'risk_reduction': reportConfigs.risk_reduction.enabled ? reportConfigs.risk_reduction.value : null
        };

        const req = this.http.post(url, body);

        return req;
    }

    getCatalog(catalogCode): Observable<any> {

        const url = this.backendUrl + 'sprisk_api/get_catalog/' + encodeURI(catalogCode);
        const req = this.http.get(url);

        return req;
    }
    getCatalogs(): Observable<any> {

        const url = this.backendUrl + 'sprisk_api/get_catalogs/';
        const req = this.http.get(url);

        return req;
    }

    saveCatalog(catalog): Observable<any> {

        const url = this.backendUrl + 'sprisk_api/save_catalog';
        const body = { 'catalog': catalog };

        const req = this.http.post(url, body);

        return req;
    }

    deleteCatalog(catalogId): Observable<any> {
        const url = this.backendUrl + 'sprisk_api/delete_catalog/' + catalogId;
        const req = this.http.get(url);

        return req;
    }

    getPart(partCode): Observable<any> {
        const url = this.backendUrl + 'sprisk_api/get_part/' + partCode;
        const req = this.http.get(url);

        return req;
    }

    getParts(): Observable<any> {
        const url = this.backendUrl + 'sprisk_api/get_parts/';
        const req = this.http.get(url);

        return req;
    }

    savePart(part): Observable<any> {

        const url = this.backendUrl + 'sprisk_api/save_part';
        const body = { 'part': part };

        const req = this.http.post(url, body);

        return req;
    }

    saveMassQualitativeAnalysis(parts): Observable<any> {

        const url = this.backendUrl + 'sprisk_api/save_mass_qualitative_analysis';
        const body = { 'parts': parts };

        const req = this.http.post(url, body);

        return req;
    }

    deletePart(partCode): Observable<any> {

        const url = this.backendUrl + 'sprisk_api/delete_part';
        const body = { 'part_code': partCode };

        const req = this.http.post(url, body);

        return req;
    }

    deleteMassParts(parts): Observable<any> {

        const url = this.backendUrl + 'sprisk_api/delete_mass_parts';
        const body = { 'parts': parts };

        const req = this.http.post(url, body);

        return req;
    }


    getFailureMode(failureModeId): Observable<any> {

        const url = this.backendUrl + 'sprisk_api/get_failure_mode/' + failureModeId;
        const req = this.http.get(url);

        return req;
    }

    getFailureModes(): Observable<any> {

        const url = this.backendUrl + 'sprisk_api/get_failure_modes/';
        const req = this.http.get(url);

        return req;
    }

    saveFailureMode(failureMode): Observable<any> {

        const url = this.backendUrl + 'sprisk_api/save_failure_mode';
        const body = { 'failure_mode': failureMode };

        const req = this.http.post(url, body);

        return req;
    }

    deleteFailureMode(failureModeId): Observable<any> {

        const url = this.backendUrl + 'sprisk_api/delete_failure_mode/' + failureModeId;
        const req = this.http.get(url);

        return req;
    }

    getFailureModeTypes(): Observable<any> {
        const url = this.backendUrl + 'sprisk_api/get_failure_mode_types';
        const req = this.http.get(url);

        return req;
    }

    saveFailureModeTypes(failureModeTypes): Observable<any> {

        const url = this.backendUrl + 'sprisk_api/save_failure_mode_types';
        const body = { 'failure_mode_types': failureModeTypes };

        const req = this.http.post(url, body);

        return req;
    }

    getQualitativeAnalysisVariables(): Observable<any> {

        const url = this.backendUrl + 'sprisk_api/get_qualitative_analysis_variables';
        const req = this.http.get(url);

        return req;
    }

    saveQualitativeAnalysisVariables(qualitativeAnalysis): Observable<any> {

        const url = this.backendUrl + 'sprisk_api/save_qualitative_analysis_variables';
        const body = { 'qualitative_analysis_variables': qualitativeAnalysis };

        const req = this.http.post(url, body);

        return req;
    }

    saveSubsystemPartsDirect(subsystems, parts): Observable<any> {

        const url = this.backendUrl + 'sprisk_api/save_subsystem_parts_direct';
        const body = { 'subsystems': subsystems, 'parts': parts };

        const req = this.http.post(url, body);

        return req;
    }

    getSubsystemPartsDirect(subsystemId): Observable<any> {

        const url = this.backendUrl + 'sprisk_api/get_subsystem_parts_direct/' + subsystemId;
        const req = this.http.get(url);

        return req;
    }

    exportSpriskPdfReport(reportData): Observable<any> {

        const url = 'http://localhost/rmes/suite-backend/pdf_generation/examples/example_001.php';
        const body = { 'report_data': reportData };

        const req = this.http.post(url, body);

        return req;
    }

    exportExcel(tableData, exportName = 'export', sheetName = 'Sheet1') {

        /* generate workbook and add the worksheet */
        const wb: XLSX.WorkBook = XLSX.utils.book_new();

        const data: XLSX.WorkSheet = XLSX.utils.aoa_to_sheet(tableData);
        XLSX.utils.book_append_sheet(wb, data, sheetName);

        /* save to file */
        const wbout: string = XLSX.write(wb, { bookType: 'xlsx', type: 'binary' });
        saveAs(new Blob([this.s2ab(wbout)]), exportName + '.xlsx');
    }

    s2ab(s: string): ArrayBuffer {
        const buf: ArrayBuffer = new ArrayBuffer(s.length);
        const view: Uint8Array = new Uint8Array(buf);
        for (let i = 0; i !== s.length; ++i) {
            view[i] = s.charCodeAt(i) & 0xFF;
        }
        return buf;
    }









    importData(importUrl, importData): Observable<any> {
        const url = importUrl;
        const body = { 'import_data': importData, 'app_locale': this.appLocale };

        const req = this.http.post(url, body);

        return req;
    }

    getImportPath(importType) {
        return this.backendUrl + this.importPaths[importType];
    }






    /** 
     * Acceso / Login
     */

    doLogin(username, password): Observable<any> {

        const url = this.backendUrl + 'api/do_login';
        const body = { 'userdata': { 'username': username, 'password': password } };

        const req = this.http.post(url, body);

        return req;
    }

    doLogout() {
        this.destroySession();
        this.router.navigate(['/login']);
    }

    destroySession() {
        this.setUser(null);
        const url = this.backendUrl + 'api/destroy_session';
        this.http.get(url).subscribe();
    }

    // TODO: Mejorar sistema de validacion
    recoverSession() {

        if (this.user !== null) {
            return null;
        }

        const userStored = localStorage.getItem('rmes_user');
        if (userStored) {
            const user = JSON.parse(userStored);
            this.setUser(user); // Se pone el usuario temporalmente para que los componentes carguen editables


            const url = this.backendUrl + 'api/recover_session';
            const body = { 'token': user.token };

            this.http.post(url, body).subscribe(data => {
                if (data['status']) {
                    this.setUser(data['user']);
                } else {
                    this.doLogout();
                }
            });
        }

        return null;
    }

    setUser(user): User {
        if (user === null) {
            this.user = null;
        } else {

            this.user = new User();

            this.user.id = user.id;
            this.user.token = user.token;
            this.user.username = user.username;
            this.user.name = user.name;
            this.user.lastName = user.last_name;
            this.user.isLoggedIn = true;

            localStorage.setItem('rmes_user', JSON.stringify(this.user));
        }

        return this.user;
    }

    isLoggedIn() {
        return this.user !== null && this.user.isLoggedIn;
    }

    // Deprecado
    userCanEdit() {
        return this.isLoggedIn();
    }

    getAppLocale() {
        return this.appLocale;
    }
}

