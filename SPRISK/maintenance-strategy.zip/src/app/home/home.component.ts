import { DataService } from './../shared/services/data.service';
import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';

declare var $: any;

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {

  public searchTerm = ''; // Usado para la busqueda de modulos
  public rmesModules = [];
  public lastUsedModule = null;

  private resultDisplayTimeout = null;

  constructor(private router: Router, private dataService: DataService) { }

  ngOnInit() {
    this.rmesModules = this.dataService.getRmesModules();

    this.rmesModules.forEach(m => {
      if (m.key === 'sprisk') {
        this.lastUsedModule = m;
      }
    });
  }

  navigateToModule(url) {

    if (url !== '#') {
      this.router.navigateByUrl('/' + url);
    }
  }

  updateResultsDisplay() {

    if (this.resultDisplayTimeout !== null) {
      clearTimeout(this.resultDisplayTimeout);
    }

    const timeoutDelay = this.searchTerm.length === 0 ? 0 : 250;

    this.resultDisplayTimeout = setTimeout(() => {

      const $searchWrapper = $('#cgs-search-results-wrapper');
      const $frequentWrapper = $('#cgs-frequently-used-wrapper');


      $searchWrapper.removeClass('uk-hidden');
      $frequentWrapper.removeClass('uk-hidden');

      const resultsHeight = $('#cgs-search-results').outerHeight();
      $searchWrapper.css('max-height', resultsHeight).css('min-height', resultsHeight);

      if (this.searchTerm.length === 0) {
        $searchWrapper.addClass('uk-hidden');
        $frequentWrapper.removeClass('uk-hidden');
      } else {
        $frequentWrapper.addClass('uk-hidden');
        $searchWrapper.removeClass('uk-hidden');
      }

    }, timeoutDelay);


  }
}
