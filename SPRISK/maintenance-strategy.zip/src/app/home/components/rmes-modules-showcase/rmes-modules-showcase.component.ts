import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { DataService } from '../../../shared/services/data.service';
import { RmesModule } from '../../../shared/classes/rmes-module';

@Component({
  selector: 'app-rmes-modules-showcase',
  templateUrl: './rmes-modules-showcase.component.html',
  styleUrls: ['./rmes-modules-showcase.component.scss']
})
export class RmesModulesShowcaseComponent implements OnInit {

  rmesModules: RmesModule[] = [];

  constructor(private router: Router, private dataService: DataService) {
    this.rmesModules = [];
  }

  ngOnInit() {
    this.rmesModules = this.dataService.getRmesModules();
  }

  navigateToModule(module) {

    if (module.url !== '#') {
      this.router.navigateByUrl('/' + module.url);
    }
  }

}
