import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RmesModulesShowcaseComponent } from './rmes-modules-showcase.component';

describe('RmesModulesShowcaseComponent', () => {
  let component: RmesModulesShowcaseComponent;
  let fixture: ComponentFixture<RmesModulesShowcaseComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RmesModulesShowcaseComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RmesModulesShowcaseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
